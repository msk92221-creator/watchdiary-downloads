// WatchDiary - Firebase 동기화 (이메일/비밀번호 로그인)
// REST API 방식, chrome.identity 없이 이메일/비밀번호로 인증.

const FIREBASE_API_KEY = "AIzaSyAm7pRevsTyF9Ewy21kdXGPXRzJh5uAYHU";
const PROJECT_ID = "watchdiary-921a0";
const AUTH_URL = `https://identitytoolkit.googleapis.com/v1/accounts`;
const FIRESTORE_BASE = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/(default)/documents`;

const FirebaseSync = {
  _cachedToken: null,
  _cachedUid: null,
  _cachedEmail: null,

  /** 이메일/비밀번호로 회원가입 또는 로그인. */
  async login(email, password, isSignUp = false) {
    const endpoint = isSignUp ? "signUp" : "signInWithPassword";
    const res = await fetch(`${AUTH_URL}:${endpoint}?key=${FIREBASE_API_KEY}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email,
        password,
        returnSecureToken: true,
      }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      const msg = err.error?.message || "로그인 실패";
      throw new Error(this._translateError(msg));
    }

    const data = await res.json();
    this._cachedToken = data.idToken;
    this._cachedUid = data.localId;
    this._cachedEmail = data.email;

    // storage에 저장 (다음 실행 시 자동 로그인).
    await chrome.storage.local.set({
      wd_token: data.idToken,
      wd_uid: data.localId,
      wd_email: data.email,
      wd_refresh: data.refreshToken,
    });

    return data.localId;
  },

  /** 저장된 토큰으로 자동 로그인 시도. */
  async autoLogin() {
    const { wd_token, wd_uid, wd_email } = await chrome.storage.local.get([
      "wd_token", "wd_uid", "wd_email",
    ]);
    if (!wd_token || !wd_uid) return null;

    // 토큰이 유효한지 확인.
    const valid = await this._verifyToken(wd_token);
    if (valid) {
      this._cachedToken = wd_token;
      this._cachedUid = wd_uid;
      this._cachedEmail = wd_email;
      return wd_uid;
    }

    // 만료시 refresh 시도.
    const refreshed = await this._refreshToken();
    return refreshed;
  },

  async _verifyToken(token) {
    try {
      const res = await fetch(`${AUTH_URL}:lookup?key=${FIREBASE_API_KEY}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ idToken: token }),
      });
      return res.ok && (await res.json()).users?.length > 0;
    } catch {
      return false;
    }
  },

  async _refreshToken() {
    const { wd_refresh } = await chrome.storage.local.get("wd_refresh");
    if (!wd_refresh) return null;
    try {
      const res = await fetch(
        `https://securetoken.googleapis.com/v1/token?key=${FIREBASE_API_KEY}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            grantType: "refresh_token",
            refreshToken: wd_refresh,
          }),
        }
      );
      if (!res.ok) return null;
      const data = await res.json();
      this._cachedToken = data.id_token;
      this._cachedUid = data.user_id;
      await chrome.storage.local.set({
        wd_token: data.id_token,
        wd_refresh: data.refresh_token,
      });
      return data.user_id;
    } catch {
      return null;
    }
  },

  async getUid() {
    if (this._cachedUid) return this._cachedUid;
    return await this.autoLogin();
  },

  async getToken() {
    if (this._cachedToken) return this._cachedToken;
    await this.autoLogin();
    return this._cachedToken;
  },

  async getEmail() {
    if (this._cachedEmail) return this._cachedEmail;
    const { wd_email } = await chrome.storage.local.get("wd_email");
    this._cachedEmail = wd_email;
    return wd_email;
  },

  /** 문서 경로 (작품 키에 공백/한글/기호가 있어도 안전하도록 인코딩). */
  _docUrl(uid, key) {
    return `${FIRESTORE_BASE}/users/${uid}/shows/${encodeURIComponent(key)}`;
  },

  /** 응답 에러를 읽어 사람이 읽을 수 있는 메시지로. */
  async _throwHttpError(res, what) {
    let detail = "";
    try {
      const body = await res.json();
      detail = body.error?.message || JSON.stringify(body);
    } catch {
      detail = await res.text().catch(() => "");
    }
    throw new Error(`${what} 실패 (HTTP ${res.status}): ${detail}`);
  },

  /** 로컬 전체 → Firestore 업로드 (업서트만, 원격 문서를 지우지 않음).
   *
   *  문서 단위 PATCH를 쓴다. :batchWrite 엔드포인트는 서버(관리자) 자격증명용이라
   *  Firebase 로그인 토큰으로 호출하면 보안 규칙과 무관하게 403이 떨어진다. */
  async uploadAll(shows) {
    const uid = await this.getUid();
    const token = await this.getToken();
    if (!uid || !token) throw new Error("로그인이 필요합니다.");

    const entries = Object.entries(shows);
    if (entries.length === 0) return true;

    const failures = [];
    const CONCURRENCY = 5;
    for (let i = 0; i < entries.length; i += CONCURRENCY) {
      const chunk = entries.slice(i, i + CONCURRENCY);
      await Promise.all(
        chunk.map(([key, show]) =>
          this.uploadOne(key, show).catch((e) => {
            failures.push(`· ${key}\n  ${e.message}`);
          })
        )
      );
    }

    if (failures.length > 0) {
      throw new Error(
        `${entries.length}개 중 ${failures.length}개 실패\n` +
          failures.slice(0, 3).join("\n")
      );
    }
    return true;
  },

  /** 단일 작품 업로드. */
  async uploadOne(key, show) {
    const uid = await this.getUid();
    const token = await this.getToken();
    if (!uid || !token) throw new Error("로그인이 필요합니다.");

    const res = await fetch(this._docUrl(uid, key), {
      method: "PATCH",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ fields: this._toFirestoreFields(show) }),
    });
    if (!res.ok) await this._throwHttpError(res, "업로드");
    return true;
  },

  /** 단일 작품 삭제 (로컬에서 지운 작품이 다음 동기화에 되살아나지 않도록). */
  async deleteOne(key) {
    const uid = await this.getUid();
    const token = await this.getToken();
    if (!uid || !token) return false;

    const res = await fetch(this._docUrl(uid, key), {
      method: "DELETE",
      headers: { Authorization: `Bearer ${token}` },
    });
    // 이미 없는 문서(404)는 성공으로 취급.
    return res.ok || res.status === 404;
  },

  /** Firestore → 로컬 다운로드. */
  async downloadAll() {
    const uid = await this.getUid();
    const token = await this.getToken();
    if (!uid || !token) throw new Error("로그인이 필요합니다.");

    const result = {};
    let pageToken = "";
    do {
      const url =
        `${FIRESTORE_BASE}/users/${uid}/shows?pageSize=300` +
        (pageToken ? `&pageToken=${encodeURIComponent(pageToken)}` : "");
      const res = await fetch(url, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) await this._throwHttpError(res, "다운로드");
      const data = await res.json();
      for (const doc of data.documents || []) {
        // 응답의 name은 인코딩되지 않은 원본 문서 ID를 담고 있음.
        const key = doc.name.split("/").pop();
        result[key] = this._fromFirestoreFields(doc.fields);
      }
      pageToken = data.nextPageToken || "";
    } while (pageToken);
    return result;
  },

  /** 로그아웃. */
  async logout() {
    await chrome.storage.local.remove([
      "wd_token", "wd_uid", "wd_email", "wd_refresh",
    ]);
    this._cachedToken = null;
    this._cachedUid = null;
    this._cachedEmail = null;
  },

  // ---- 에러 메시지 번역 ----

  _translateError(msg) {
    const map = {
      "EMAIL_EXISTS": "이미 가입된 이메일입니다. 로그인하세요.",
      "EMAIL_NOT_FOUND": "가입되지 않은 이메일입니다.",
      "INVALID_PASSWORD": "비밀번호가 틀렸습니다.",
      "INVALID_EMAIL": "올바르지 않은 이메일 형식입니다.",
      "WEAK_PASSWORD": "비밀번호는 6자 이상이어야 합니다.",
      "USER_DISABLED": "비활성화된 계정입니다.",
      "TOO_MANY_ATTEMPTS_TRY_LATER": "너무 많은 시도. 잠시 후 다시 시도하세요.",
      "OPERATION_NOT_ALLOWED": "이메일/비밀번호 로그인이 활성화되지 않았습니다.",
    };
    return map[msg] || `오류: ${msg}`;
  },

  // ---- Firestore 필드 변환 ----

  /** 작품 객체 → Firestore fields 맵 (Document.fields에 그대로 들어갈 값). */
  _toFirestoreFields(obj) {
    const fields = {};
    for (const [k, v] of Object.entries(obj)) {
      fields[k] = this._toFieldValue(v);
    }
    return fields;
  },

  _toFieldValue(v) {
    if (v === null || v === undefined) return { nullValue: null };
    if (typeof v === "string") return { stringValue: v };
    if (typeof v === "number") {
      // 정수/실수 구분 (실수를 integerValue로 보내면 400).
      return Number.isInteger(v)
        ? { integerValue: String(v) }
        : { doubleValue: v };
    }
    if (typeof v === "boolean") return { booleanValue: v };
    if (typeof v === "object") {
      // episodes 등 중첩 구조는 JSON 문자열로 저장 (앱과 합의된 형식).
      return { stringValue: JSON.stringify(v) };
    }
    return { nullValue: null };
  },

  _fromFirestoreFields(fields) {
    const result = {};
    for (const [k, v] of Object.entries(fields || {})) {
      result[k] = this._fromFieldValue(v);
    }
    // episodes는 JSON 문자열(확장 저장분) 또는 중첩 map(구버전 앱 저장분) 양쪽 허용.
    if (typeof result.episodes === "string") {
      try {
        result.episodes = JSON.parse(result.episodes);
      } catch {
        result.episodes = {};
      }
    }
    if (result.episodes === null || typeof result.episodes !== "object") {
      result.episodes = {};
    }
    return result;
  },

  _fromFieldValue(v) {
    if (!v) return null;
    if (v.stringValue !== undefined) return v.stringValue;
    if (v.integerValue !== undefined) return parseInt(v.integerValue, 10);
    if (v.doubleValue !== undefined) return v.doubleValue;
    if (v.booleanValue !== undefined) return v.booleanValue;
    if (v.nullValue !== undefined) return null;
    if (v.timestampValue !== undefined) {
      return Date.parse(v.timestampValue) || null;
    }
    if (v.mapValue !== undefined) {
      const out = {};
      for (const [k, mv] of Object.entries(v.mapValue.fields || {})) {
        out[k] = this._fromFieldValue(mv);
      }
      return out;
    }
    if (v.arrayValue !== undefined) {
      return (v.arrayValue.values || []).map((av) => this._fromFieldValue(av));
    }
    return null;
  },
};
