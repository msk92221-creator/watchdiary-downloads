// WatchDiary - background service worker (멀티 OTT)
// 역할:
//   1. content script로부터 재생 상태 수신 → chrome.storage에 저장
//   2. SPA URL 변경 감지 (5개 OTT) → content script에 재초기화 통지
//   3. 팝업의 "해당 위치로 이동" 요청 처리 (탭 생성/이동)
//   4. Firebase Firestore 동기화 (폰과 양방향)

// Firebase 동기화 모듈 로드.
importScripts("firebase-sync.js");

const STORAGE_KEY = "shows";

// OTT별 도메인 매핑 (webNavigation 필터용).
const OTT_HOSTS = [
  { hostEquals: "www.netflix.com", platform: "netflix", pathPrefix: "/watch/" },
  { hostEquals: "www.disneyplus.com", platform: "disney", pathPrefix: "/play/" },
  { hostEquals: "www.wavve.com", platform: "wavve", pathPrefix: "/player/" },
  { hostEquals: "www.tving.com", platform: "tving", pathPrefix: null }, // 여러 경로
  { hostEquals: "play.watcha.com", platform: "watcha", pathPrefix: null },
  { hostEquals: "watcha.com", platform: "watcha", pathPrefix: null },
];

/** content script 메시지 수신 */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "PLAYBACK_STATE" && msg.data) {
    savePlayback(msg.data)
      .then(() => sendResponse({ ok: true }))
      .catch((e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg?.type === "OPEN_AT_POSITION" && msg.url) {
    // 팝업에서 "해당 위치로 이동" 클릭 시: 이미 열린 탭이 있으면 이동, 없으면 새 탭.
    openAtPosition(msg.url, msg.positionSec || 0);
    sendResponse({ ok: true });
    return false;
  }
  if (msg?.type === "CHECK_EXTENSION_UPDATE") {
    checkExtensionUpdate()
      .then(sendResponse)
      .catch((e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  sendResponse({ ok: false });
  return false;
});

/** 작품이 아닌 사이트 UI 문구인지 확인. */
function isInvalidCollectedTitle(rawTitle) {
  const title = String(rawTitle || "").normalize("NFKC").trim();
  if (!title) return true;
  return /^(?:개인정보\s*(?:선호|보호)\s*센터|쿠키\s*(?:설정|선호)|privacy\s*preference\s*center|cookie\s*(?:preferences?|settings?)|manage\s*preferences?|netflix)$/i.test(title);
}
/** 플레이어 UI 문구는 회차/재생 근거가 없을 때 저장하지 않는다. */
function isPlayerUiTitle(rawTitle) {
  const title = String(rawTitle || "").normalize("NFKC").trim();
  return /^(?:자막|자막\s*(?:및|&)\s*음성|음성|오디오|설정|재생|일시정지|다음\s*(?:화|에피소드)|건너뛰기|광고|미리보기|전체\s*화면|subtitles?|audio|settings?|play|pause|next\s*episode|skip\s*(?:intro|recap|credits)|advertisement|preview|fullscreen)$/i.test(title);
}

/** 제목 끝의 회차 표기만 제거한다. 접두사 유사도는 사용하지 않는다. */
function canonicalizeShowTitle(rawTitle, platform, season, episode) {
  let title = String(rawTitle || "")
    .normalize("NFKC")
    .replace(/[\u200B-\u200D\uFEFF]/g, "")
    .replace(/\s+/g, " ")
    .trim();

  const episodeSuffixes = [
    /\s*(?:[-–—|:]\s*)?S(?:EASON)?\s*\d+\s*E(?:PISODE)?\s*\d+\s*$/i,
    /\s*(?:[-–—|:]\s*)?(?:시즌\s*\d+\s*)?제?\s*\d+\s*화\s*$/i,
    /\s*(?:[-–—|:]\s*)?(?:시즌\s*\d+\s*)?EP(?:ISODE)?\.?\s*\d+\s*$/i,
  ];
  const leadingIndex = /^\s*\d{1,3}\s*[.)-]\s+(?=\S)/;
  const platformTail =
    /\s+(?:[|·]|[-–—])\s*(?:TVING|티빙|NETFLIX|넷플릭스|DISNEY\+?|디즈니\s*플러스|WAVVE|웨이브|WATCHA|왓챠)\s*$/i;

  let previous;
  do {
    previous = title;
    for (const pattern of episodeSuffixes) title = title.replace(pattern, "").trim();
    title = title.replace(leadingIndex, "").replace(platformTail, "").trim();
  } while (title && title !== previous);

  // 넷플릭스의 "시리즈명: 회차 부제" 구조는 회차 정보가 있을 때만 분리한다.
  if (platform === "netflix" && season != null && episode != null) {
    const seriesMatch = title.match(/^(.{2,60}?)[：:]\s*(\S.+)$/u);
    if (seriesMatch) title = seriesMatch[1].trim();
  }

  return title || String(rawTitle || "").trim();
}

/** 재생 상태를 chrome.storage에 저장/갱신 */
async function savePlayback(state) {
  if (!state.title || state.title.length === 0) return;

  const result = await chrome.storage.local.get(STORAGE_KEY);
  const shows = result[STORAGE_KEY] || {};

  const season = state.season;
  const episode = state.episode;
  const canonicalTitle = canonicalizeShowTitle(state.title, state.platform, season, episode);
  if (isInvalidCollectedTitle(canonicalTitle)) return;
  if (
    isPlayerUiTitle(canonicalTitle) &&
    season == null &&
    episode == null &&
    Number(state.positionSec || 0) <= 0
  ) return;
  // 작품 키: 플랫폼 + 정규화된 제목. 같은 접두사라는 이유만으로 합치지 않는다.
  const showKey = `${state.platform}::${canonicalTitle}`;

  if (!shows[showKey]) {
    shows[showKey] = {
      title: canonicalTitle,
      platform: state.platform,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      latestSeason: season,
      latestEpisode: episode,
      lastWatchedAt: Date.now(),
      lastUrl: state.url,
      episodes: {},
    };
  }

  const show = shows[showKey];
  show.updatedAt = Date.now();
  show.lastWatchedAt = Date.now();
  show.title = canonicalTitle;
  show.platform = state.platform;
  show.lastUrl = state.url;

  if (season && episode) {
    const epKey = `${season}-${episode}`;
    const existing = show.episodes[epKey] || {};
    show.episodes[epKey] = {
      season,
      episode,
      positionSec: state.positionSec,
      positionText: formatTime(state.positionSec),
      durationSec: state.durationSec,
      paused: state.paused,
      url: state.url,
      watchedAt: existing.watchedAt || Date.now(),
      updatedAt: Date.now(),
    };
    // 최신 회차 갱신.
    if (
      show.latestSeason == null ||
      season > show.latestSeason ||
      (season === show.latestSeason && episode > (show.latestEpisode || 0))
    ) {
      show.latestSeason = season;
      show.latestEpisode = episode;
    }
  } else {
    // 시즌/에피소드 미식별 (영화 등) - 단순 위치 기록.
    show.positionSec = state.positionSec;
    show.positionText = formatTime(state.positionSec);
  }

  await chrome.storage.local.set({ [STORAGE_KEY]: shows });

  // Firebase에도 업로드 (폰과 동기화). 미로그인 상태면 조용히 건너뜀.
  const uid = await FirebaseSync.getUid().catch(() => null);
  if (!uid) return;
  FirebaseSync.uploadOne(showKey, show)
    .then(() => console.log("[WatchDiary] 업로드 완료:", showKey))
    .catch((e) => {
      console.warn("[WatchDiary] Firebase 업로드 실패:", e.message);
    });
}

/** 초 → mm:ss 또는 h:mm:ss */
function formatTime(sec) {
  if (!sec || sec < 0) return "0:00";
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  const mm = String(m).padStart(2, "0");
  const ss = String(s).padStart(2, "0");
  return h > 0 ? `${h}:${mm}:${ss}` : `${mm}:${ss}`;
}

/** 해당 위치로 이동: 같은 OTT 탭이 있으면 그 탭으로, 없으면 새 탭.
 *  위치 이동(t=초)은 content script가 URL 해시로 받아 seek. */
async function openAtPosition(url, positionSec) {
  // 같은 OTT 도메인의 기존 탭 찾기.
  const urlObj = new URL(url);
  const targetHost = urlObj.hostname;
  const tabs = await chrome.tabs.query({ url: `*://${targetHost}/*` });

  // 시간을 URL 해시로 추가 (content script가 읽어서 video.currentTime 설정).
  const urlWithPos = `${url}#wd_t=${positionSec}`;

  if (tabs.length > 0) {
    // 기존 탭에서 이동.
    await chrome.tabs.update(tabs[0].id, {
      url: urlWithPos,
      active: true,
    });
    chrome.tabs.reload(tabs[0].id).catch(() => {});
  } else {
    // 새 탭.
    await chrome.tabs.create({ url: urlWithPos, active: true });
  }
}

// ---- SPA URL 변경 감지 (모든 OTT) ----

// 각 OTT 호스트별로 webNavigation 리스너 등록.
for (const ott of OTT_HOSTS) {
  chrome.webNavigation.onHistoryStateUpdated.addListener(
    (details) => {
      chrome.tabs
        .sendMessage(details.tabId, {
          type: "URL_CHANGED",
          url: details.url,
          platform: ott.platform,
        })
        .catch(() => {});
    },
    { url: [{ hostEquals: ott.hostEquals }] }
  );
}

console.log("[WatchDiary] background service worker 활성화 (5개 OTT 지원)");

// ---- 자동 업데이트 확인 ----

// 확장 자체 버전 (manifest.json과 동일).
const CURRENT_VERSION = chrome.runtime.getManifest().version;
const GITHUB_REPO = "msk92221-creator/watchdiary-downloads";
/** 점으로 구분된 확장 버전을 비교. a가 b보다 새 버전이면 true. */
function isNewerVersion(a, b) {
  const left = String(a).split(".").map(Number);
  const right = String(b).split(".").map(Number);
  const length = Math.max(left.length, right.length);
  for (let i = 0; i < length; i += 1) {
    const diff = (left[i] || 0) - (right[i] || 0);
    if (diff !== 0) return diff > 0;
  }
  return false;
}

/** GitHub에서 최신 Release 확인.
 *  Release body에 "ext: X.X.X" 가 있으면 확장 버전으로 인식. */
async function checkExtensionUpdate() {
  try {
    const res = await fetch(
      `https://api.github.com/repos/${GITHUB_REPO}/releases/latest`
    );
    if (!res.ok) throw new Error(`GitHub 응답 오류 (${res.status})`);
    const release = await res.json();

    // Release body에서 확장 버전 추출 ("ext: 3.1.3" 형태).
    const body = release.body || "";
    const extMatch = body.match(/ext:\s*(\d+(?:\.\d+){1,3})/i);
    if (!extMatch) {
      return { ok: false, error: "Release 설명에서 ext 버전을 찾지 못했습니다." };
    }
    const latestExtVersion = extMatch[1];
    const extAsset = (release.assets || []).find(
      (asset) => asset.name === "WatchDiary-extension.zip"
    );
    const updateUrl =
      extAsset?.browser_download_url ||
      `https://github.com/${GITHUB_REPO}/raw/refs/heads/main/WatchDiary-extension.zip`;
    const updateAvailable = isNewerVersion(latestExtVersion, CURRENT_VERSION);

    if (updateAvailable) {
      chrome.action.setBadgeText({ text: "NEW" });
      chrome.action.setBadgeBackgroundColor({ color: "#e50914" });
      await chrome.storage.local.set({
        update_available: true,
        update_version: latestExtVersion,
        update_url: updateUrl,
        update_html: release.html_url,
      });
      console.log(
        `[WatchDiary] 새 확장 버전 감지: ${latestExtVersion} (현재: ${CURRENT_VERSION})`
      );
    } else {
      chrome.action.setBadgeText({ text: "" });
      await chrome.storage.local.remove([
        "update_available", "update_version", "update_url", "update_html",
      ]);
    }

    return {
      ok: true,
      updateAvailable,
      currentVersion: CURRENT_VERSION,
      latestVersion: latestExtVersion,
      updateUrl,
      releaseUrl: release.html_url,
    };
  } catch (e) {
    return { ok: false, error: e.message || "업데이트 확인에 실패했습니다." };
  }
}

// 서비스 워커 시작 시 + 1시간마다 확인.
checkExtensionUpdate();
chrome.alarms?.create("checkUpdate", { periodInMinutes: 60 });
chrome.alarms?.onAlarm.addListener((alarm) => {
  if (alarm.name === "checkUpdate") checkExtensionUpdate();
});
