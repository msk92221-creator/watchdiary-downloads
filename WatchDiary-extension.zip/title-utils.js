// WatchDiary - 제목 정규화/계열 통합 공용 모듈 (background + popup)
// OTT 플레이어는 같은 작품을 "귀멸의 칼날", "귀멸의 칼날: 참나무꾼",
// "골든하우스 E57. 누구네 집"처럼 회차/부제가 붙은 제목으로 넘겨온다.
// 이 모듈은 그 변형들을 하나의 대표 작품으로 합쳐 카드가 늘어나는 것을 막는다.

(function (global) {
  "use strict";

  // 공백 경계로 이어진 조사/접속사는 같은 계열로 보지 않는다.
  // 예: "해리 포터" vs "해리 포터 와 마법사의 돌" → 다른 작품으로 취급.
  const CONNECTOR_TOKENS = new Set([
    "와", "과", "의", "및", "그리고", "또는", "또한", "랑", "이랑", "from", "and", "or",
  ]);

  /** 제목 정규화: NFKC + zero-width 제거 + 공백 단일화. */
  function normalizeTitleText(rawTitle) {
    return String(rawTitle || "")
      .normalize("NFKC")
      .replace(/[​-‍﻿]/g, "")
      .replace(/\s+/g, " ")
      .trim();
  }

  /** 구두점/공백 차이를 무시한 제목 식별자. */
  function foldTitleIdentity(rawTitle) {
    return normalizeTitleText(rawTitle)
      .toLocaleLowerCase("ko-KR")
      .replace(/[^\p{L}\p{N}]+/gu, "");
  }

  /**
   * baseTitle이 variantTitle의 앞부분(대표 작품명)이면 남는 부분(부제)을 반환.
   * 경계 규칙:
   *   - ":", "|", "-", "·" 등 구분자가 사이에 있으면 부제로 인정.
   *   - 공백 경계만 있을 때는 첫 토큰이 조사/접속사이면 다른 작품으로 판단.
   *   - 경계가 아예 없으면(한글 붙은 형태) 다른 작품으로 판단.
   */
  function variantSuffixAfterBase(baseTitle, variantTitle) {
    const base = normalizeTitleText(baseTitle);
    const variant = normalizeTitleText(variantTitle);
    if (!base || !variant || base === variant) return null;
    if (!variant.startsWith(base)) return null;
    if (foldTitleIdentity(base).length < 2) return null;

    const rest = variant.slice(base.length);
    const punctBoundary =
      /[\s:：|·\-–—]$/.test(base) || /^[\s:：|·\-–—]/.test(rest);
    if (!punctBoundary) return null;

    const suffix = rest
      .replace(/^[\s:：|·\-–—]+/u, "")
      .replace(/[\s:：|·\-–—]+$/u, "")
      .trim();
    if (foldTitleIdentity(suffix).length < 2) return null;

    // 공백으로만 이어진 경우 조사/접속사 시작이면 별개 작품으로 본다.
    const firstToken = suffix.split(/\s+/)[0] || "";
    if (/^\s/.test(rest) && CONNECTOR_TOKENS.has(firstToken)) {
      return null;
    }
    return suffix;
  }

  // 회차 번호로 시작하는 부분(예: "E57.", "제12화", "3화 ").
  const EPISODE_MARKER = /^(?:E?P?ISODE?\.?\s*\d+|제?\s*\d+\s*[화회]|\d{1,3}\s*[.)-]\s)/i;
  const SEPARATORS = "[\\s:：|·\\-–—]";

  /**
   * 둘 다 부제 변형일 때(어느 쪽도 상대의 대표작이 아닐 때)가 공통 대표작명을 반환.
   * 예: "귀멸의 칼날: 참나무꾼" + "귀멸의 칼날: 오니의 형제" → "귀멸의 칼날".
   * 구분자 없이 이어진 한국어 제목("슬기로운 의사생활" vs "슬기로운 감빵생활")은
   * 별개 작품으로 판단한다.
   */
  function sharedBaseTitle(a, b) {
    const left = normalizeTitleText(a);
    const right = normalizeTitleText(b);
    if (!left || !right) return null;

    let index = 0;
    while (
      index < left.length &&
      index < right.length &&
      left[index] === right[index]
    ) {
      index += 1;
    }
    const rawPrefix = left.slice(0, index);
    const base = rawPrefix.replace(new RegExp(SEPARATORS + "+$"), "").trim();
    if (!base || foldTitleIdentity(base).length < 2) return null;
    if (base === left || base === right) return null; // 직접 base-variant면 여기 없음

    const nextLeft = left.slice(base.length);
    const nextRight = right.slice(base.length);
    const strongLeft = new RegExp("^(?::|：|\\||·)").test(nextLeft);
    const strongRight = new RegExp("^(?::|：|\\||·)").test(nextRight);
    if (strongLeft || strongRight) return base;

    // 공백/대시 경계만 있으면 한쪽이라도 회차 표기로 시작해야 같은 계열로 본다.
    const boundaryLeft = new RegExp("^(?:\\s|[-–—])").test(nextLeft);
    const boundaryRight = new RegExp("^(?:\\s|[-–—])").test(nextRight);
    if (boundaryLeft && EPISODE_MARKER.test(nextLeft.trim())) return base;
    if (boundaryRight && EPISODE_MARKER.test(nextRight.trim())) return base;
    return null;
  }

  /** 두 제목이 같은 계열(대표작-부제변형)인지. 순서 무관. */
  function areTitleFamily(a, b) {
    return (
      variantSuffixAfterBase(a, b) !== null ||
      variantSuffixAfterBase(b, a) !== null
    );
  }

  // ---- 회차/작품 병합 유틸 ----

  /** 회차 맵 합집합 (같은 회차는 더 최근 기록 우선). */
  function mergeEpisodeMaps(a, b) {
    const out = { ...(a || {}) };
    for (const [epKey, ep] of Object.entries(b || {})) {
      const current = out[epKey];
      if (!current) {
        out[epKey] = ep;
        continue;
      }
      const currentTs = current.updatedAt || current.watchedAt || 0;
      const incomingTs = ep.updatedAt || ep.watchedAt || 0;
      if (incomingTs > currentTs) out[epKey] = ep;
    }
    return out;
  }

  function showTimestamp(show) {
    return show?.lastWatchedAt || show?.updatedAt || show?.createdAt || 0;
  }

  /** 회차 맵에서 시청 시각 기준 가장 최근 회차. */
  function mostRecentEpisode(episodes) {
    let best = null;
    for (const [key, rawEpisode] of Object.entries(episodes || {})) {
      const episode = { ...(rawEpisode || {}) };
      const keyParts = key.split("-").map(Number);
      if (!Number.isFinite(Number(episode.season))) episode.season = keyParts[0] || 0;
      if (!Number.isFinite(Number(episode.episode))) episode.episode = keyParts[1] || 0;
      const timestamp = Number(episode.updatedAt || episode.watchedAt || 0) || 0;
      if (!best || timestamp > best.timestamp) {
        best = { episode, timestamp };
      }
    }
    return best?.episode || null;
  }

  /** 회차 맵에서 번호가 가장 앞선 시즌/회차. */
  function highestEpisodeOf(episodes) {
    let latest = null;
    for (const ep of Object.values(episodes || {})) {
      if (ep.season == null || ep.episode == null) continue;
      if (
        !latest ||
        ep.season > latest.season ||
        (ep.season === latest.season && ep.episode > latest.episode)
      ) {
        latest = { season: ep.season, episode: ep.episode };
      }
    }
    return latest;
  }

  /** 여러 작품 레코드를 하나의 대표 작품으로 합친다. */
  function mergeShowEntries(entries, canonicalTitle, platform) {
    const newestFirst = [...entries].sort(
      (a, b) => showTimestamp(b) - showTimestamp(a)
    );
    const newest = newestFirst[0];
    let episodes = {};
    for (const entry of [...entries].sort(
      (a, b) => showTimestamp(a) - showTimestamp(b)
    )) {
      episodes = mergeEpisodeMaps(episodes, entry.episodes || {});
    }

    const createdTimes = entries
      .map((entry) => entry.createdAt)
      .filter((value) => Number.isFinite(value) && value > 0);
    const merged = {
      ...newest,
      title: canonicalTitle,
      platform: platform,
      createdAt: createdTimes.length ? Math.min(...createdTimes) : Date.now(),
      updatedAt: Date.now(),
      lastWatchedAt: Math.max(...entries.map((entry) => showTimestamp(entry))),
      episodes,
    };

    const highest = highestEpisodeOf(episodes);
    if (highest) {
      merged.latestSeason = highest.season;
      merged.latestEpisode = highest.episode;
    }
    const recent = mostRecentEpisode(episodes);
    if (recent?.url) merged.lastUrl = recent.url;
    if (recent?.positionText) merged.positionText = recent.positionText;
    if (Number.isFinite(Number(recent?.positionSec))) {
      merged.positionSec = Number(recent.positionSec);
    }
    return merged;
  }

  /**
   * 플랫폼별로 대표작-부제변형 관계인 작품들을 하나로 합친다.
   * extraEntry를 넘기면(아직 저장 전인 새 작품) 그 작품이 속할 최종 키도 알려준다.
   *
   * @returns {{
   *   shows: object,                // 통합된 작품 맵 (원본 보존)
   *   removedKeys: string[],        // 통합되어 사라진 저장 키
   *   targetKeys: string[],         // 통합 결과가 저장된 키
   *   extraTargetKey: string|null,  // extraEntry가 저장되어야 할 키
   * }}
   */
  function consolidateShows(shows, extraEntry) {
    const result = {
      shows: { ...(shows || {}) },
      removedKeys: [],
      targetKeys: [],
      extraTargetKey: null,
    };
    if (!shows || typeof shows !== "object") return result;

    const platformOf = (key, show) =>
      String(show?.platform || key.split("::")[0] || "etc").toLowerCase();

    // 노드 목록: 저장된 작품 + (있다면) 저장 전 신규 후보.
    const nodes = [];
    for (const [key, show] of Object.entries(shows)) {
      nodes.push({
        key,
        title: normalizeTitleText(show?.title || key.split("::").slice(1).join("::")),
        platform: platformOf(key, show),
        show,
      });
    }
    if (extraEntry?.title) {
      nodes.push({
        key: null,
        title: normalizeTitleText(extraEntry.title),
        platform: String(extraEntry.platform || "etc").toLowerCase(),
        show: null,
        isExtra: true,
      });
    }

    // 유니온-파인드: 같은 플랫폼에서 식별자가 같거나 대표작-변형 관계면 묶는다.
    const parent = nodes.map((_, index) => index);
    const find = (index) => {
      while (parent[index] !== index) {
        parent[index] = parent[parent[index]];
        index = parent[index];
      }
      return index;
    };
    const union = (a, b) => {
      const ra = find(a);
      const rb = find(b);
      if (ra !== rb) parent[rb] = ra;
    };

    const identities = nodes.map((node) => foldTitleIdentity(node.title));
    for (let i = 0; i < nodes.length; i += 1) {
      for (let j = i + 1; j < nodes.length; j += 1) {
        if (nodes[i].platform !== nodes[j].platform) continue;
        const sameIdentity =
          identities[i].length >= 2 && identities[i] === identities[j];
        if (
          !sameIdentity &&
          !areTitleFamily(nodes[i].title, nodes[j].title) &&
          !sharedBaseTitle(nodes[i].title, nodes[j].title)
        ) {
          continue;
        }
        union(i, j);
      }
    }

    const groups = new Map();
    nodes.forEach((node, index) => {
      const root = find(index);
      if (!groups.has(root)) groups.set(root, []);
      groups.get(root).push(node);
    });

    for (const group of groups.values()) {
      const realEntries = group.filter((node) => !node.isExtra);
      const extraNodes = group.filter((node) => node.isExtra);
      if (realEntries.length + extraNodes.length < 2) {
        // 혼자인 신규 후보는 자기 자신 키로.
        if (extraNodes.length === 1) {
          result.extraTargetKey = `${extraNodes[0].platform}::${extraNodes[0].title}`;
        }
        continue;
      }

      // 대표 제목: 그룹 전체의 공통 접두사(대표작명) → 없으면 가장 짧은 제목.
      let lcp = group[0].title;
      for (const node of group.slice(1)) {
        let index = 0;
        while (
          index < lcp.length &&
          index < node.title.length &&
          lcp[index] === node.title[index]
        ) {
          index += 1;
        }
        lcp = lcp.slice(0, index);
      }
      const lcpBase = lcp
        .replace(new RegExp(SEPARATORS + "+$"), "")
        .trim();
      const sorted = [...group].sort((a, b) => {
        if (a.title.length !== b.title.length) return a.title.length - b.title.length;
        return a.title.localeCompare(b.title, "ko-KR");
      });
      const canonicalTitle =
        lcpBase && foldTitleIdentity(lcpBase).length >= 2 ? lcpBase : sorted[0].title;
      const platform = sorted[0].platform;
      const targetKey = `${platform}::${canonicalTitle}`;

      if (realEntries.length > 0) {
        const merged = mergeShowEntries(
          realEntries.map((node) => node.show),
          canonicalTitle,
          platform
        );
        for (const node of realEntries) {
          delete result.shows[node.key];
          if (node.key !== targetKey) result.removedKeys.push(node.key);
        }
        delete merged.key;
        result.shows[targetKey] = merged;
        result.targetKeys.push(targetKey);
      }
      if (extraNodes.length > 0) result.extraTargetKey = targetKey;
    }
    return result;
  }

  global.TitleUtils = {
    normalizeTitleText,
    foldTitleIdentity,
    variantSuffixAfterBase,
    areTitleFamily,
    sharedBaseTitle,
    mergeEpisodeMaps,
    mostRecentEpisode,
    highestEpisodeOf,
    consolidateShows,
  };
})(typeof self !== "undefined" ? self : globalThis);
