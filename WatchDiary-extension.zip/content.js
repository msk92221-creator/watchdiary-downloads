// WatchDiary - content script (멀티 OTT)
// 넷플릭스/디즈니+/웨이브/티빙/왓챠 DOM에서 재생 정보를 추출해 background로 전달.
//
// 추출 우선순위:
//   1순위: video.currentTime (표준 API - 100% 안정)
//   2순위: 사이트별 DOM 선택자 (다중 폴백)
//   3순위: document.title / og:title (최후의 보루)

(() => {
  "use strict";

  let pollTimer = null;
  let lastSentTs = 0;
  let lastSentKey = "";
  let lastSentPosition = 0;
  let attachedVideo = null;
  let obs = null;
  let navigationChangedAt = Date.now();
  let pendingCandidateKey = "";
  let pendingCandidateSince = 0;
  let seekPollTimer = null;
  let seekGiveUpTimer = null;
  const CANDIDATE_STABLE_MS = 700;
  const NAVIGATION_SETTLE_MS = 1500;

  // ---- 현재 OTT 식별 ----

  function detectPlatform() {
    const host = location.hostname;
    if (host.includes("netflix.com")) return "netflix";
    if (host.includes("disneyplus.com")) return "disney";
    if (host.includes("wavve.com")) return "wavve";
    if (host.includes("tving.com")) return "tving";
    if (host.includes("watcha.com") || host.includes("watcha.tv"))
      return "watcha";
    return "etc";
  }

  /** 재생 페이지인지 판별 (각 OTT별 URL 패턴). */
  function isWatchPage() {
    const p = location.pathname;
    const plat = detectPlatform();
    switch (plat) {
      case "netflix":
        return p.includes("/watch/");
      case "disney":
        return p.includes("/play/");
      case "wavve":
        return p.startsWith("/player/");
      case "tving":
        // /view/, /video/, /contents/ 모두 포괄
        return (
          p.includes("/view/") ||
          p.includes("/video/") ||
          p.includes("/player/")
        );
      case "watcha":
        return p.includes("/watch/") || p.includes("/play/");
      default:
        return !!findVideo();
    }
  }

  // ---- video 요소 ----

  function findVideo() {
    return (
      document.querySelector(".VideoContainer video") ||
      document.querySelector(".watch-video video") ||
      document.querySelector("video")
    );
  }

  // ---- 제목/에피소드 추출 (사이트별 폴백 체인) ----

  /** 사이트별 제목 선택자 체인 */
  function titleSelectors() {
    const plat = detectPlatform();
    const common = [
      '[class*="player"][class*="title"]',
      '[class*="title"]:not([class*="episode"])',
      'h1',
    ];
    switch (plat) {
      case "netflix":
        return [
          '[data-uia="player-title"]',
          '[data-uia="video-title"]',
          ".video-title h4",
          ...common,
        ];
      case "disney":
        // Disney+ 검증 선택자 + Shadow DOM 대응
        return [
          ".title-field",
          '[class*="title-field"]',
          ...common,
        ];
      case "wavve":
        return [
          ".player-title",
          ".vod-title",
          ".program-title",
          '[class*="title"]',
          ...common,
        ];
      case "tving":
        // CSS-in-JS 해시 클래스 → 부분 매칭 전략
        return [
          '[class*="title"]',
          '[aria-label]',
          ...common,
        ];
      case "watcha":
        return [
          '[class*="player"][class*="title"]',
          '[class*="title"]',
          "h1",
          ...common,
        ];
      default:
        return common;
    }
  }

  function metaSelectors() {
    const plat = detectPlatform();
    const common = [
      '[class*="episode"]',
      '[class*="subtitle"]',
    ];
    switch (plat) {
      case "netflix":
        return [
          '[data-uia="episode-title"]',
          ".episode-title",
          '[data-uia="player-episode-title"]',
          ...common,
        ];
      case "disney":
        return [".subtitle-field", '[class*="subtitle-field"]', ...common];
      case "wavve":
      case "tving":
      case "watcha":
        return [
          '[class*="episode"]',
          '[class*="subtitle"]',
          ...common,
        ];
      default:
        return common;
    }
  }

  const ignoredTitlePatterns = [
    /^(?:개인정보\s*(?:선호|보호)\s*센터|쿠키\s*(?:설정|선호))$/i,
    /^(?:privacy\s*preference\s*center|cookie\s*(?:preferences?|settings?)|manage\s*preferences?)$/i,
    /^(?:netflix|disney\+?|tving|wavve|watcha)$/i,
    /^(?:자막|자막\s*(?:및|&)\s*음성|음성|오디오|설정|재생|일시정지|다음\s*(?:화|에피소드)|건너뛰기|광고|미리보기|전체\s*화면)$/i,
    /^(?:subtitles?|audio|settings?|play|pause|next\s*episode|skip\s*(?:intro|recap|credits)|advertisement|preview|fullscreen)$/i,
  ];

  function isIgnoredTitle(text) {
    const normalized = String(text || "").normalize("NFKC").trim();
    return !normalized || ignoredTitlePatterns.some((pattern) => pattern.test(normalized));
  }

  function isConsentUiElement(el) {
    return !!el?.closest?.(
      '#onetrust-consent-sdk, #onetrust-banner-sdk, [id*="onetrust"], ' +
      '[class*="onetrust"], [aria-label*="Privacy Preference" i]'
    );
  }

  function findTitleText() {
    // 1순위: 사이트별 선택자. 개인정보/쿠키 UI 안의 문구는 제외한다.
    for (const sel of titleSelectors()) {
      try {
        for (const el of document.querySelectorAll(sel)) {
          if (isConsentUiElement(el)) continue;
          const text = el?.textContent?.trim();
          if (
            text &&
            text.length > 0 &&
            text.length < 200 &&
            !isIgnoredTitle(text)
          ) {
            return text;
          }
        }
      } catch (e) {
        /* 선택자 오류 무시 */
      }
    }
    // 2순위: og:title 메타.
    const og = document.querySelector('meta[property="og:title"]')?.content;
    if (og && og.trim() && !isIgnoredTitle(og)) return og.trim();
    // 3순위: document.title (사이트명/개인정보 UI 문구 제외).
    const dt = document.title.trim();
    if (dt && dt.length > 0 && dt.length < 200 && !isIgnoredTitle(dt)) {
      return dt;
    }
    return null;
  }
  function findMetaText() {
    for (const sel of metaSelectors()) {
      try {
        const el = document.querySelector(sel);
        const text = el?.textContent?.trim();
        if (text && text.length > 0 && text.length < 200) return text;
      } catch (e) {
        /* 무시 */
      }
    }
    return null;
  }

  /**
   * 원시 타이틀에서 {title, season, episode} 파싱.
   * 지원 형태:
   *   "S2:E5 '참나무꾼'"     (넷플릭스/디즈니+)
   *   "시즌 2: 5. 참나무꾼"   (웨이브)
   *   "제1회" / "1화"          (티빙/왓챠)
   *   "Episode 5"             (영문)
   */
  function stripExactTrailingMetaTitle(rawTitle, metaText, hasEpisode) {
    const base = String(rawTitle || "")
      .normalize("NFKC")
      .replace(/\s+/g, " ")
      .trim();
    const tail = String(metaText || "")
      .normalize("NFKC")
      .replace(/\s+/g, " ")
      .trim();
    if (!hasEpisode || tail.length < 2) return base;

    // OTT DOM은 작품명과 회차 정보를 한 요소에 붙여 쓰기도 한다.
    // 회차 번호가 구조적으로 확인된 경우에만, metaText 전체와 번호를 뺀
    // 회차 부제를 정확한 꼬리 후보로 사용한다.
    const subtitleOnly = tail
      .replace(
        /^(?:S(?:EASON)?\s*\d+\s*[:E\-]+\s*\d+|시즌\s*\d+\s*[:：.]?\s*\d+|제?\s*\d+\s*[화회]|E(?:PISODE|P)?\.?\s*\d+|\d{1,3}\s*[.)-])\s*(?:[.):：|·\-–—]\s*)?/iu,
        ""
      )
      .replace(/^[\s'"“”‘’]+|[\s'"“”‘’]+$/gu, "")
      .trim();
    const candidates = [...new Set([tail, subtitleOnly])]
      .filter((candidate) => candidate.length >= 2 && candidate.length < base.length)
      .sort((a, b) => b.length - a.length);

    for (const candidate of candidates) {
      if (!base.endsWith(candidate)) continue;
      const prefix = base
        .slice(0, -candidate.length)
        .replace(/[\s:：|·\-–—]+$/u, "")
        .trim();
      if (prefix.replace(/[^\p{L}\p{N}]+/gu, "").length >= 2) return prefix;
    }
    return base;
  }

  function parseTitle(rawTitle, metaText) {
    let title = rawTitle || "";
    let season = null;
    let episode = null;

    const combined = `${title} ${metaText || ""}`;

    // S2:E5 / S2 E5 / S2E5
    const sxxexx = combined.match(/S(\d+)\s*[:E]+\s*(\d+)/i);
    if (sxxexx) {
      season = parseInt(sxxexx[1], 10);
      episode = parseInt(sxxexx[2], 10);
    } else {
      // 시즌 2: 5 / 시즌2 5화
      const korean = combined.match(/시즌\s*(\d+)\s*[:：.]?\s*(\d+)/);
      if (korean) {
        season = parseInt(korean[1], 10);
        episode = parseInt(korean[2], 10);
      } else {
        // 제1회 / 1화 / 제1화
        const korEp = combined.match(/제?\s*(\d+)\s*[화회]/);
        if (korEp) {
          episode = parseInt(korEp[1], 10);
          season = season || 1;
        } else {
          // Episode 5 / Ep.5
          const epOnly = combined.match(/E(?:pisode|p)?\.?\s*(\d+)/i);
          if (epOnly) {
            episode = parseInt(epOnly[1], 10);
            season = season || 1;
          }
        }
      }
    }

    title = stripExactTrailingMetaTitle(title, metaText, season != null && episode != null);

    // 시즌/에피소드 부분을 title에서 제거해 순수 작품명 추출.
    if (season && episode) {
      title = title
        .replace(/S\d+\s*[:E]+\s*\d+/i, "")
        .replace(/시즌\s*\d+\s*[:：.]?\s*\d+/, "")
        .trim();
    }
    title = title
      .replace(/제?\s*\d+\s*[화회]/, "")
      .replace(/['""].*['""]/g, "")
      .trim();

    if (isIgnoredTitle(title)) return { title: null, season, episode };
    return { title: title || rawTitle, season, episode };
  }

  // Node 회귀 테스트에서만 파서에 접근하고 실제 확장 환경에는 노출하지 않는다.
  if (globalThis.__WATCHDIARY_TEST_HOOK__) {
    Object.assign(globalThis.__WATCHDIARY_TEST_HOOK__, {
      stripExactTrailingMetaTitle,
      parseTitle,
    });
    return;
  }

  function collectState() {
    const video = findVideo();
    if (!video) return null;

    const rawTitle = findTitleText();
    const metaText = findMetaText();
    const parsed = parseTitle(rawTitle, metaText);

    return {
      title: parsed.title,
      season: parsed.season,
      episode: parsed.episode,
      platform: detectPlatform(),
      positionSec: Math.floor(video.currentTime || 0),
      durationSec: Math.floor(video.duration || 0),
      paused: video.paused,
      url: location.href.split("#")[0],
      rawTitle: rawTitle,
      ts: Date.now(),
    };
  }

  // ---- 전송 ----

  function maybeSend() {
    if (!isWatchPage()) return;
    const state = collectState();
    if (!state) return;
    if (!state.title || state.title.length === 0) return;

    const key = `${state.platform}|${state.title}|S${state.season}|E${state.episode}`;
    const now = Date.now();
    const candidateKey = `${key}|${state.url}`;
    if (candidateKey !== pendingCandidateKey) {
      pendingCandidateKey = candidateKey;
      pendingCandidateSince = now;
      return;
    }
    if (
      now - pendingCandidateSince < CANDIDATE_STABLE_MS ||
      now - navigationChangedAt < NAVIGATION_SETTLE_MS
    ) {
      return;
    }
    const posDelta = Math.abs(state.positionSec - lastSentPosition);

    if (candidateKey !== lastSentKey) {
      send(state, candidateKey);
    } else if (posDelta >= 5 && now - lastSentTs >= 5000) {
      send(state, candidateKey);
    }
  }

  function send(state, key) {
    chrome.runtime.sendMessage({ type: "PLAYBACK_STATE", data: state });
    lastSentKey = key;
    lastSentTs = Date.now();
    lastSentPosition = state.positionSec;
  }

  // ---- 초기화 / 감시 ----

  function attach() {
    const video = findVideo();
    if (!video) return false;
    if (attachedVideo === video) return true;

    if (attachedVideo) {
      attachedVideo.removeEventListener("timeupdate", maybeSend);
      attachedVideo.removeEventListener("play", maybeSend);
      attachedVideo.removeEventListener("pause", maybeSend);
    }
    attachedVideo = video;
    video.addEventListener("timeupdate", maybeSend);
    video.addEventListener("play", maybeSend);
    video.addEventListener("pause", maybeSend);
    console.log(`[WatchDiary] ${detectPlatform()} video 요소 감지, 모니터링 시작`);
    return true;
  }

  function startWatching() {
    if (pollTimer) clearInterval(pollTimer);
    pollTimer = setInterval(() => {
      if (isWatchPage() && attach()) {
        clearInterval(pollTimer);
        pollTimer = null;
      }
    }, 500);

    if (obs) obs.disconnect();
    obs = new MutationObserver(() => {
      attach();
      maybeSend();
    });
    obs.observe(document.body, { childList: true, subtree: true });
  }

  function reset() {
    if (pollTimer) {
      clearInterval(pollTimer);
      pollTimer = null;
    }
    if (attachedVideo) {
      attachedVideo.removeEventListener("timeupdate", maybeSend);
      attachedVideo.removeEventListener("play", maybeSend);
      attachedVideo.removeEventListener("pause", maybeSend);
      attachedVideo = null;
    }
    if (obs) {
      obs.disconnect();
      obs = null;
    }
    lastSentKey = "";
    lastSentTs = 0;
    navigationChangedAt = Date.now();
    pendingCandidateKey = "";
    pendingCandidateSince = 0;
    startWatching();
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg?.type === "URL_CHANGED") {
      console.log("[WatchDiary] URL 변경, 재초기화", msg.url);
      reset();
    }
    if (msg?.type === "SEEK_TO_POSITION") {
      seekToPosition(msg.positionSec);
    }
    sendResponse?.({ ok: true });
    return true;
  });

  // 시작: 재생 페이지에서만.
  if (isWatchPage()) {
    startWatching();
    trySeekFromHash();
  } else {
    // 재생 페이지가 아니어도 SPA 전환 감지를 위해 관찰 시작.
    startWatching();
  }

  // ---- "해당 위치로 이동" 처리 ----
  // video 로드 후 지정 위치로 seek. OTT URL 자체는 변경하지 않는다.
  function seekToPosition(positionSec, clearLegacyHash = false) {
    const targetSec = Math.max(0, Math.floor(Number(positionSec) || 0));
    if (!targetSec || targetSec <= 0) return;

    console.log(`[WatchDiary] 저장 위치로 이동: ${targetSec}초`);
    if (seekPollTimer) clearInterval(seekPollTimer);
    if (seekGiveUpTimer) clearTimeout(seekGiveUpTimer);

    // video 로드 대기 후 seek. 재생 시작은 OTT 플레이어에 맡긴다.
    seekPollTimer = setInterval(() => {
      const v = findVideo();
      if (v && v.readyState >= 2) {
        try {
          const duration = Number(v.duration);
          v.currentTime = Number.isFinite(duration) && duration > 1
            ? Math.min(targetSec, duration - 1)
            : targetSec;
        } catch (e) {
          /* seek 차단 가능성 */
        }
        clearInterval(seekPollTimer);
        seekPollTimer = null;
        if (clearLegacyHash) {
          // 이전 버전의 wd_t 해시만 제거한다.
          history.replaceState(null, "", location.pathname + location.search);
        }
      }
    }, 300);
    // 15초 후 포기.
    seekGiveUpTimer = setTimeout(() => {
      if (seekPollTimer) clearInterval(seekPollTimer);
      seekPollTimer = null;
      seekGiveUpTimer = null;
    }, 15000);
  }

  // 구버전이 만든 URL도 한 번은 복구한다.
  function trySeekFromHash() {
    const hash = location.hash || "";
    const m = hash.match(/wd_t=(\d+)/);
    if (!m) return;
    seekToPosition(parseInt(m[1], 10), true);
  }

  // URL_CHANGED 메시지에서도 해시 seek 재시도.
  const origListener = true;
  if (origListener) {
    // 이미 위에서 URL_CHANGED 리스너 등록됨 - 추가로 해시 처리 훅.
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg?.type === "URL_CHANGED" && location.hash.includes("wd_t=")) {
        setTimeout(trySeekFromHash, 1000);
      }
      return false;
    });
  }
})();
