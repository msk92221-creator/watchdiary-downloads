# WatchDiary - 내 OTT 시청 기록 (크롬/엣지 확장)

공유 OTT 계정에서 **내가 본 작품의 진도만 자동으로 기록**. 앱 없이 확장 하나만으로 작동.

## ✨ 특징
- 넷플릭스/디즈니+/웨이브/티빙/왓챠 재생 시 **자동으로 진도/재생 위치 기록**
- 확장 아이콘 클릭 → 내 시청 목록 팝업
- **플랫폼별 / 전체 보기 토글** — 전체 보기는 플랫폼 구분 없이 본 순서대로 표시
- 회차별 상세 위치 (mm:ss) 표시, 회차 목록은 **최근에 본 순서**로 정렬
- 같은 작품의 부제 변형("작품명: 회차부제", "작품명 E57. 부제")을 **자동으로 하나로 통합**
- 검색 / 데이터 내보내기(JSON) / 전체 삭제
- 수동 업데이트 확인 / 기존 중복 작품 목록 안전 정리
- Firebase 클라우드 동기화 (폰 앱과 양방향, 선택)

## 📦 설치 (엣지/크롬)
1. `edge://extensions` (또는 `chrome://extensions`) 접속
2. **개발자 모드** 켜기
3. **"압축해제된 확장 로드"** 클릭
4. 이 `extension/` 폴더 선택

## 📺 사용
1. OTT 사이트에서 작품 재생
2. 자동으로 진도가 기록됨 (회차가 감지된 경우)
3. 확장 아이콘 클릭 → 시청 목록 확인
4. 상단 **플랫폼별 / 전체** 버튼으로 보기 방식 전환
5. 작품 클릭 → 회차별 상세 위치 펼침 (최근 시청순)

## 🔍 감지 원리
- `video.currentTime` (표준 API - 안정적) 으로 재생 위치 추출
- `[data-uia="player-title"]` 등에서 제목/시즌/에피소드 파싱 (다중 폴백)
- 5초 이상 위치 변화 시 저장 (과도한 저장 방지)
- 저장 시 제목 정규화 + 계열 통합(`title-utils.js`)으로 카드 중복 방지

## ⚠️ 한계
- 각 OTT **웹 버전에서만** 작동 (윈도우 앱/TV 불가)
- OTT가 DOM을 변경하면 회차 감지가 깨질 수 있음 (재생 위치는 안정적)
- 시즌/에피소드가 식별된 시리즈만 회차별 기록 (영화는 위치만)

## 📁 파일 구조
```
extension/
├── manifest.json    # MV3 선언
├── content.js       # OTT DOM 감지
├── background.js    # chrome.storage 저장 + 계열 통합
├── title-utils.js   # 제목 정규화/계열 통합 공용 모듈
├── firebase-sync.js # 클라우드 동기화
├── popup.html       # 진도 목록 UI
├── popup.css        # 다크 테마 스타일
└── popup.js         # 목록 로드/검색/보기 토글/내보내기
```

## 💾 데이터 구조 (chrome.storage.local)
```json
{
  "shows": {
    "netflix::오징어게임": {
      "title": "오징어게임",
      "platform": "netflix",
      "latestSeason": 2,
      "latestEpisode": 5,
      "lastWatchedAt": 1730000000000,
      "episodes": {
        "2-5": {
          "season": 2, "episode": 5,
          "positionSec": 1395, "positionText": "23:15",
          "watchedAt": 1730000000000
        }
      }
    }
  }
}
```
