// WatchDiary popup - OTT 그룹화 + 위치 이동 + 수동 편집/삭제

const STORAGE_KEY = "shows";

const PLATFORM_LABELS = {
  netflix: "Netflix",
  disney: "Disney+",
  wavve: "Wavve",
  tving: "TVING",
  watcha: "왓챠",
  etc: "기타",
};

const PLATFORM_ORDER = ["netflix", "disney", "tving", "wavve", "watcha", "etc"];

// 접기/펼치기 상태 (세션 유지).
const collapsedPlatforms = new Set();
// 삭제 모드에서 선택된 작품 키.
const selectedKeys = new Set();
let deleteMode = false;
// 정렬 기준.
let sortBy = "recent";

document.addEventListener("DOMContentLoaded", () => {
  loadShows();
  updateSyncStatus();
  checkUpdateBanner();
  autoPull();
  document.getElementById("checkUpdateBtn").addEventListener("click", handleManualUpdateCheck);
  document.getElementById("cleanupDuplicatesBtn").addEventListener("click", cleanupDuplicateShows);
  document.getElementById("searchInput").addEventListener("input", loadShows);
  document.getElementById("clearBtn").addEventListener("click", confirmClearAll);
  document.getElementById("exportBtn").addEventListener("click", exportData);
  document.getElementById("importBtn").addEventListener("click", () => {
    document.getElementById("importFile").click();
  });
  document.getElementById("importFile").addEventListener("change", importData);

  // 삭제 모드 토글.
  document.getElementById("editModeBtn").addEventListener("click", toggleDeleteMode);
  document.getElementById("cancelDeleteBtn").addEventListener("click", toggleDeleteMode);
  document.getElementById("confirmDeleteBtn").addEventListener("click", deleteSelected);
  // 클라우드 동기화.
  document.getElementById("syncBtn").addEventListener("click", handleSync);
  document.getElementById("sortSelect").addEventListener("change", (e) => {
    sortBy = e.target.value;
    loadShows();
  });
  // 설정 패널 토글.
  document.getElementById("settingsBtn").addEventListener("click", () => {
    const panel = document.getElementById("settingsPanel");
    const btn = document.getElementById("settingsBtn");
    panel.classList.toggle("hidden");
    btn.classList.toggle("active");
    loadCleanupSetting();
  });
  // 자동 삭제 설정 변경.
  document.getElementById("autoCleanupSelect").addEventListener("change", (e) => {
    const days = parseInt(e.target.value, 10);
    chrome.storage.local.set({ auto_cleanup_days: days });
    if (days > 0) {
      runAutoCleanup(days);
    }
  });
  // 시작 시 자동 삭제 실행.
  chrome.storage.local.get("auto_cleanup_days", (data) => {
    const days = data.auto_cleanup_days || 0;
    if (days > 0) runAutoCleanup(days);
  });
});

/** 자동 삭제 설정 불러오기. */
async function loadCleanupSetting() {
  const { auto_cleanup_days } = await chrome.storage.local.get("auto_cleanup_days");
  document.getElementById("autoCleanupSelect").value = String(auto_cleanup_days || 0);
}

/** 설정한 기간 이상 안 본 작품 자동 삭제 (로컬 + 클라우드). */
async function runAutoCleanup(days) {
  const result = await chrome.storage.local.get(STORAGE_KEY);
  const shows = result[STORAGE_KEY] || {};
  const threshold = Date.now() - days * 24 * 60 * 60 * 1000;
  const toDelete = [];
  for (const [key, show] of Object.entries(shows)) {
    const ts = show.lastWatchedAt || 0;
    if (ts > 0 && ts < threshold) {
      delete shows[key];
      toDelete.push(key);
    }
  }
  if (toDelete.length > 0) {
    // 1. 로컬에서 삭제.
    await chrome.storage.local.set({ [STORAGE_KEY]: shows });
    // 2. 클라우드에서도 삭제.
    for (const key of toDelete) {
      try {
        await FirebaseSync.deleteOne(key);
      } catch (e) {
        console.warn("[WatchDiary] 클라우드 삭제 실패:", key, e.message);
      }
    }
    console.log(`[WatchDiary] 자동 삭제: ${toDelete.length}개 (${days}일 이상 미시청)`);
    loadShows();
  }
}

/** 클라우드 동기화 상태 표시. */
async function updateSyncStatus() {
  const statusEl = document.getElementById("syncStatus");
  if (!statusEl) return;
  const uid = await FirebaseSync.getUid();
  const email = await FirebaseSync.getEmail();
  if (uid) {
    statusEl.className = "synced";
    statusEl.textContent = `☁ ${email || "동기화됨"}`;
  } else {
    statusEl.className = "not-synced";
    statusEl.textContent = "☁ 클라우드 미연결 (🔄 눌러 로그인)";
  }
}

/** 팝업을 열 때 클라우드 데이터를 조용히 내려받아 병합. */
async function autoPull() {
  try {
    const uid = await FirebaseSync.getUid();
    if (!uid) return;
    await flushPendingCleanupDeletes();
    const cloudShows = await FirebaseSync.downloadAll();
    if (!cloudShows || Object.keys(cloudShows).length === 0) return;

    const result = await chrome.storage.local.get(STORAGE_KEY);
    const merged = mergeShows(result[STORAGE_KEY] || {}, cloudShows);
    await chrome.storage.local.set({ [STORAGE_KEY]: merged });
    loadShows();
  } catch (e) {
    console.warn("[WatchDiary] 자동 동기화 실패:", e.message);
  }
}

/** 동기화 버튼: 로그인 → 다운로드 병합 → 병합 결과 업로드. */
async function handleSync() {
  const btn = document.getElementById("syncBtn");
  const original = btn.textContent;
  btn.textContent = "⏳";
  btn.disabled = true;

  try {
    // 자동 로그인 시도.
    let uid = await FirebaseSync.getUid();
    if (!uid) {
      // 로그인 창 표시.
      uid = await showLoginDialog();
      if (!uid) {
        btn.textContent = original;
        btn.disabled = false;
        return;
      }
    }

    // 오프라인 정리 때 예약된 예전 중복 키를 내려받기 전에 먼저 삭제.
    await flushPendingCleanupDeletes();

    // 1) 먼저 내려받아 병합 (업로드가 폰에만 있는 기록을 덮어쓰지 않도록).
    const result = await chrome.storage.local.get(STORAGE_KEY);
    const localShows = result[STORAGE_KEY] || {};
    const cloudShows = await FirebaseSync.downloadAll();
    const merged = mergeShows(localShows, cloudShows || {});
    await chrome.storage.local.set({ [STORAGE_KEY]: merged });

    // 2) 병합 결과를 업로드.
    await FirebaseSync.uploadAll(merged);

    btn.textContent = "✅";
    loadShows();
    updateSyncStatus();
    setTimeout(() => { btn.textContent = original; btn.disabled = false; }, 1500);
  } catch (e) {
    btn.textContent = "❌";
    // 업로드가 실패했어도 내려받아 병합한 내용은 이미 저장됐으므로 화면은 갱신.
    loadShows();
    updateSyncStatus();
    alert("동기화 실패: " + e.message);
    setTimeout(() => { btn.textContent = original; btn.disabled = false; }, 1500);
  }
}

// ---- 병합 로직 (확장 ↔ 클라우드) ----

/** 로컬/클라우드 작품 병합. 최신 시청 기록 우선, 회차는 항상 합집합. */
function mergeShows(localShows, cloudShows) {
  const merged = { ...localShows };

  for (const [key, cloud] of Object.entries(cloudShows)) {
    const local = merged[key];
    if (!local) {
      merged[key] = cloud;
      continue;
    }

    const localTs = local.lastWatchedAt || local.updatedAt || 0;
    const cloudTs = cloud.lastWatchedAt || cloud.updatedAt || 0;
    // 메타데이터는 더 최근 쪽을 우선.
    const base = cloudTs > localTs
      ? { ...local, ...cloud }
      : { ...cloud, ...local };

    base.episodes = mergeEpisodes(local.episodes, cloud.episodes);
    // 병합된 회차 기준으로 최신 진도 재계산.
    const latest = latestOf(base.episodes);
    if (latest) {
      base.latestSeason = latest.season;
      base.latestEpisode = latest.episode;
    }
    merged[key] = base;
  }

  return merged;
}

/** 회차 맵 합집합 (같은 회차는 더 최근 기록 우선). */
function mergeEpisodes(a, b) {
  const out = { ...(a || {}) };
  for (const [epKey, ep] of Object.entries(b || {})) {
    const current = out[epKey];
    if (!current) {
      out[epKey] = ep;
      continue;
    }
    const currentTs = current.updatedAt || current.watchedAt || 0;
    const incomingTs = ep.updatedAt || ep.watchedAt || 0;
    if (incomingTs > currentTs) out[epKey] = ep;
  }
  return out;
}

/** 회차 맵에서 가장 앞선 시즌/회차 찾기. */
function latestOf(episodes) {
  let latest = null;
  for (const ep of Object.values(episodes || {})) {
    if (ep.season == null || ep.episode == null) continue;
    if (
      !latest ||
      ep.season > latest.season ||
      (ep.season === latest.season && ep.episode > latest.episode)
    ) {
      latest = { season: ep.season, episode: ep.episode };
    }
  }
  return latest;
}

/** 로그인 다이얼로그 (이메일/비밀번호 + 회원가입). */
async function showLoginDialog() {
  return new Promise((resolve) => {
    // 로그인 오버레이 생성.
    const overlay = document.createElement("div");
    overlay.style.cssText = `
      position: fixed; top: 0; left: 0; right: 0; bottom: 0;
      background: rgba(0,0,0,0.9); display: flex; align-items: center;
      justify-content: center; z-index: 9999; padding: 20px;`;
    overlay.innerHTML = `
      <div style="background: #1a1a1a; border-radius: 12px; padding: 24px; width: 100%; max-width: 300px;">
        <h2 style="color: #e50914; margin: 0 0 16px; font-size: 16px;">☁️ 클라우드 로그인</h2>
        <input id="loginEmail" type="email" placeholder="이메일"
          style="width:100%;padding:8px;margin-bottom:8px;background:#222;border:1px solid #333;border-radius:4px;color:#fff;font-size:13px;box-sizing:border-box;" />
        <input id="loginPw" type="password" placeholder="비밀번호 (6자 이상)"
          style="width:100%;padding:8px;margin-bottom:12px;background:#222;border:1px solid #333;border-radius:4px;color:#fff;font-size:13px;box-sizing:border-box;" />
        <div style="display:flex;gap:8px;">
          <button id="loginBtn" style="flex:1;padding:8px;background:#e50914;color:#fff;border:none;border-radius:4px;cursor:pointer;font-weight:600;font-size:13px;">로그인</button>
          <button id="signupBtn" style="flex:1;padding:8px;background:#333;color:#fff;border:none;border-radius:4px;cursor:pointer;font-size:13px;">회원가입</button>
        </div>
        <button id="cancelLogin" style="width:100%;margin-top:8px;padding:6px;background:none;color:#666;border:none;cursor:pointer;font-size:12px;">취소</button>
        <p style="color:#555;font-size:10px;margin-top:8px;text-align:center;">같은 이메일로 폰 앱과 PC 확장<br>모두 로그인하면 동기화됩니다</p>
      </div>`;
    document.body.appendChild(overlay);

    const close = (uid) => {
      overlay.remove();
      resolve(uid);
    };

    overlay.querySelector("#cancelLogin").onclick = () => close(null);

    overlay.querySelector("#loginBtn").onclick = async () => {
      const email = overlay.querySelector("#loginEmail").value.trim();
      const pw = overlay.querySelector("#loginPw").value;
      if (!email || !pw) return;
      try {
        overlay.querySelector("#loginBtn").textContent = "⏳";
        const uid = await FirebaseSync.login(email, pw, false);
        close(uid);
      } catch (e) {
        alert(e.message);
        overlay.querySelector("#loginBtn").textContent = "로그인";
      }
    };

    overlay.querySelector("#signupBtn").onclick = async () => {
      const email = overlay.querySelector("#loginEmail").value.trim();
      const pw = overlay.querySelector("#loginPw").value;
      if (!email || !pw) return;
      try {
        overlay.querySelector("#signupBtn").textContent = "⏳";
        const uid = await FirebaseSync.login(email, pw, true);
        close(uid);
      } catch (e) {
        alert(e.message);
        overlay.querySelector("#signupBtn").textContent = "회원가입";
      }
    };
  });
}

// ---- 삭제 모드 ----

function toggleDeleteMode() {
  deleteMode = !deleteMode;
  document.body.classList.toggle("delete-mode", deleteMode);
  document.getElementById("editModeBtn").classList.toggle("active", deleteMode);
  document.getElementById("deleteToolbar").classList.toggle("active", deleteMode);
  if (!deleteMode) selectedKeys.clear();
  updateSelectedInfo();
  loadShows();
}

function updateSelectedInfo() {
  document.getElementById("selectedInfo").textContent = `${selectedKeys.size}개 선택됨`;
  document.getElementById("confirmDeleteBtn").disabled = selectedKeys.size === 0;
}

async function deleteSelected() {
  if (selectedKeys.size === 0) return;

  const result = await chrome.storage.local.get(STORAGE_KEY);
  const shows = result[STORAGE_KEY] || {};
  // 화면용 key 필드나 검색 상태와 무관하게 실제 저장 키가 존재하는 항목만 삭제.
  const keys = [...selectedKeys].filter((key) =>
    Object.prototype.hasOwnProperty.call(shows, key)
  );
  if (keys.length === 0) {
    selectedKeys.clear();
    updateSelectedInfo();
    return;
  }
  const preview = keys
    .slice(0, 5)
    .map((key) => `• ${shows[key]?.title || key}`)
    .join("\n");
  const more = keys.length > 5 ? `\n외 ${keys.length - 5}개` : "";
  if (!confirm(
    `아래 ${keys.length}개 작품만 삭제합니다.\n\n${preview}${more}\n\n` +
    `(로그인 상태면 폰에서도 삭제됩니다)`
  )) return;

  for (const key of keys) delete shows[key];
  await chrome.storage.local.set({ [STORAGE_KEY]: shows });
  await deleteFromCloud(keys);
  selectedKeys.clear();
  deleteMode = false;
  document.body.classList.remove("delete-mode");
  document.getElementById("editModeBtn").classList.remove("active");
  document.getElementById("deleteToolbar").classList.remove("active");
  updateSelectedInfo();
  loadShows();
}

/** 클라우드에서도 삭제 (안 하면 다음 동기화에 되살아남). */
async function deleteFromCloud(keys) {
  try {
    const uid = await FirebaseSync.getUid();
    if (!uid) return;
    await Promise.all(keys.map((key) => FirebaseSync.deleteOne(key)));
  } catch (e) {
    console.warn("[WatchDiary] 클라우드 삭제 실패:", e.message);
  }
}

// ---- 메인 로드 ----

async function loadShows() {
  const search = document
    .getElementById("searchInput")
    .value.trim()
    .toLowerCase();
  const result = await chrome.storage.local.get(STORAGE_KEY);
  const shows = result[STORAGE_KEY] || {};
  let list = Object.entries(shows).map(([key, s]) => ({ ...s, key }));

  // 정렬.
  switch (sortBy) {
    case "recent":
      list.sort((a, b) => (b.lastWatchedAt || 0) - (a.lastWatchedAt || 0));
      break;
    case "registered":
      list.sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
      break;
    case "title":
      list.sort((a, b) => String(a.title || "").localeCompare(String(b.title || "")));
      break;
    case "platform":
      list.sort((a, b) => String(a.platform || "").localeCompare(String(b.platform || "")));
      break;
  }

  if (search) {
    list = list.filter((s) =>
      String(s.title || "").toLowerCase().includes(search)
    );
  }

  const totalEpisodes = list.reduce(
    (sum, s) => sum + Object.keys(s.episodes || {}).length,
    0
  );
  document.getElementById(
    "stats"
  ).textContent = `${list.length}개 작품 · ${totalEpisodes}화 시청`;

  // 플랫폼별 그룹화.
  const grouped = {};
  for (const s of list) {
    const p = s.platform || "etc";
    (grouped[p] = grouped[p] || []).push(s);
  }

  const listEl = document.getElementById("showList");
  const emptyEl = document.getElementById("empty");
  listEl.innerHTML = "";

  if (list.length === 0) {
    emptyEl.classList.remove("hidden");
    listEl.classList.add("hidden");
    return;
  }
  emptyEl.classList.add("hidden");
  listEl.classList.remove("hidden");

  for (const platform of PLATFORM_ORDER) {
    if (!grouped[platform] || grouped[platform].length === 0) continue;
    listEl.appendChild(renderPlatformGroup(platform, grouped[platform]));
  }
}

function renderPlatformGroup(platform, shows) {
  const group = document.createElement("div");
  group.className = "ott-group";

  const isCollapsed = collapsedPlatforms.has(platform);
  const totalEps = shows.reduce(
    (sum, s) => sum + Object.keys(s.episodes || {}).length,
    0
  );

  const header = document.createElement("div");
  header.className = "ott-group-header" + (isCollapsed ? " collapsed" : "");
  header.innerHTML = `
    <span class="chevron">▼</span>
    <span class="platform-badge ${platform}">${platformLabel(platform)}</span>
    <span style="font-weight:600;font-size:13px;">${platformLabel(platform)}</span>
    <span style="color:#888;font-size:11px;margin-left:auto;">${shows.length}개 작품 · ${totalEps}화</span>
  `;
  header.addEventListener("click", () => {
    if (collapsedPlatforms.has(platform)) collapsedPlatforms.delete(platform);
    else collapsedPlatforms.add(platform);
    loadShows();
  });
  group.appendChild(header);

  const content = document.createElement("div");
  content.className = "ott-group-content" + (isCollapsed ? " collapsed" : "");
  for (const show of shows) {
    content.appendChild(renderShowItem(show));
  }
  group.appendChild(content);

  return group;
}

function renderShowItem(show) {
  const li = document.createElement("li");
  li.className = "show-item";
  if (selectedKeys.has(show.key)) li.classList.add("selected");

  const episodeCount = Object.keys(show.episodes || {}).length;
  const latest =
    show.latestSeason && show.latestEpisode
      ? `S${show.latestSeason} E${show.latestEpisode}까지`
      : show.positionText
      ? show.positionText
      : "기록 없음";

  let latestResume = "";
  let latestUrl = show.lastUrl;
  let latestPosSec = 0;
  if (show.latestSeason && show.latestEpisode) {
    const ep = (show.episodes || {})[`${show.latestSeason}-${show.latestEpisode}`];
    if (ep) {
      if (ep.positionText) latestResume = `⏱ ${ep.positionText}`;
      if (ep.url) latestUrl = ep.url;
      latestPosSec = ep.positionSec || 0;
    }
  }

  const metaParts = [];
  metaParts.push(`총 ${episodeCount}화`);
  metaParts.push(relativeTime(show.lastWatchedAt));

  li.innerHTML = `
    <div class="show-title-row">
      <input type="checkbox" class="show-checkbox" data-key="${escapeAttr(show.key)}" ${selectedKeys.has(show.key) ? "checked" : ""} />
      <span class="show-title">${escapeHtml(show.title)}</span>
      <span class="show-progress">${latest}</span>
      <div class="show-actions">
        <button class="edit-btn" title="수정">✎</button>
        <button class="delete-action quick-del" title="삭제" data-key="${escapeAttr(show.key)}">🗑</button>
      </div>
    </div>
    <div class="show-meta">${metaParts.join(" · ")}${latestResume ? ` · <span class="resume">${latestResume}</span>` : ""}</div>
    <div class="episodes-detail">${renderEpisodes(show)}</div>
    <div class="edit-form">${renderEditForm(show)}</div>
  `;

  // 체크박스.
  const checkbox = li.querySelector(".show-checkbox");
  checkbox.addEventListener("click", (e) => {
    e.stopPropagation();
    if (checkbox.checked) {
      selectedKeys.add(show.key);
      li.classList.add("selected");
    } else {
      selectedKeys.delete(show.key);
      li.classList.remove("selected");
    }
    updateSelectedInfo();
  });

  // 빠른 삭제 (개별).
  li.querySelector(".quick-del").addEventListener("click", (e) => {
    e.stopPropagation();
    deleteSingle(show.key);
  });

  // 수정 버튼.
  li.querySelector(".edit-btn").addEventListener("click", (e) => {
    e.stopPropagation();
    li.classList.add("editing");
  });

  // 수정 저장/취소.
  li.querySelector(".save-btn")?.addEventListener("click", (e) => {
    e.stopPropagation();
    saveEdit(li, show);
  });
  li.querySelector(".cancel-edit-btn")?.addEventListener("click", (e) => {
    e.stopPropagation();
    li.classList.remove("editing");
  });

  // 회차 추가 버튼.
  li.querySelector(".ep-add-btn")?.addEventListener("click", (e) => {
    e.stopPropagation();
    addEpRow(li.querySelector(".ep-edit-list"));
  });

  // 회차 개별 삭제.
  li.querySelectorAll(".ep-del").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      btn.closest(".ep-edit-row").remove();
    });
  });

  // 일반 클릭: 회차 상세 토글 / 회차 이동.
  li.addEventListener("click", (e) => {
    if (li.classList.contains("editing")) return;
    if (e.target.closest(".show-checkbox, .show-actions, .edit-form, .ep-edit-row, .ep-add-btn")) return;

    // 삭제 모드에서는 카드 전체가 선택 토글 영역이다. 상세 열기와 혼동하지 않는다.
    if (deleteMode) {
      e.stopPropagation();
      checkbox.checked = !checkbox.checked;
      if (checkbox.checked) {
        selectedKeys.add(show.key);
        li.classList.add("selected");
      } else {
        selectedKeys.delete(show.key);
        li.classList.remove("selected");
      }
      updateSelectedInfo();
      return;
    }

    const epRow = e.target.closest(".ep-row");
    if (epRow && epRow.dataset.url) {
      e.stopPropagation();
      openAtPosition(epRow.dataset.url, parseInt(epRow.dataset.pos || "0", 10));
      return;
    }
    if (e.target.classList.contains("resume-btn")) {
      e.stopPropagation();
      openAtPosition(latestUrl, latestPosSec);
      return;
    }
    li.classList.toggle("expanded");
  });

  return li;
}

function renderEpisodes(show) {
  const episodes = Object.values(show.episodes || {});
  if (episodes.length === 0) {
    return show.positionText
      ? `<div class="ep-row"><span>현재 위치</span><span class="ep-pos">${show.positionText}</span></div>`
      : "<div class='ep-row'>회차 정보 없음</div>";
  }
  episodes.sort((a, b) => {
    if (a.season !== b.season) return a.season - b.season;
    return a.episode - b.episode;
  });
  const rows = episodes
    .map((ep) => {
      const posAttr = ep.url ? `data-url="${escapeAttr(ep.url)}" data-pos="${ep.positionSec || 0}"` : "";
      return `<div class="ep-row" ${posAttr}><span>S${ep.season} E${ep.episode} <span style="color:#46d369;">▶</span></span><span class="ep-pos">${ep.positionText || ""}</span></div>`;
    })
    .join("");
  const lastEp = episodes[episodes.length - 1];
  const resumeBtn = lastEp?.url
    ? `<div class="ep-row" style="padding:4px 0;border-bottom:1px solid #222;margin-bottom:4px;"><button class="resume-btn" style="background:#e50914;color:#fff;border:none;padding:4px 10px;border-radius:4px;cursor:pointer;font-size:11px;font-weight:600;">▶ 최근 위치에서 이어보기 (${lastEp.positionText || "0:00"})</button></div>`
    : "";
  return resumeBtn + rows;
}

// ---- 인라인 편집 폼 ----

function renderEditForm(show) {
  const episodes = Object.values(show.episodes || {}).sort((a, b) => {
    if (a.season !== b.season) return a.season - b.season;
    return a.episode - b.episode;
  });

  const epRows = episodes
    .map(
      (ep, i) => `
      <div class="ep-edit-row">
        <input type="number" class="ep-num ep-season" value="${ep.season}" placeholder="시즌" />
        <input type="number" class="ep-num ep-episode" value="${ep.episode}" placeholder="회차" />
        <input type="text" class="ep-pos-input" value="${ep.positionText || ""}" placeholder="위치(mm:ss)" />
        <button class="ep-del" title="이 회차 삭제">✕</button>
      </div>`
    )
    .join("");

  return `
    <label>작품명</label>
    <input type="text" class="edit-title" value="${escapeAttr(show.title)}" />
    <label>회차별 위치</label>
    <div class="ep-edit-list">${epRows}</div>
    <button class="ep-add-btn">+ 회차 추가</button>
    <div class="edit-actions">
      <button class="cancel-edit-btn">취소</button>
      <button class="save-btn">저장</button>
    </div>
  `;
}

function addEpRow(listEl) {
  const row = document.createElement("div");
  row.className = "ep-edit-row";
  row.innerHTML = `
    <input type="number" class="ep-num ep-season" value="1" placeholder="시즌" />
    <input type="number" class="ep-num ep-episode" value="1" placeholder="회차" />
    <input type="text" class="ep-pos-input" value="" placeholder="위치(mm:ss)" />
    <button class="ep-del" title="이 회차 삭제">✕</button>
  `;
  row.querySelector(".ep-del").addEventListener("click", (e) => {
    e.stopPropagation();
    row.remove();
  });
  listEl.appendChild(row);
}

/** 편집 폼 내용을 저장 */
async function saveEdit(li, show) {
  const newTitle = li.querySelector(".edit-title").value.trim();
  if (!newTitle) {
    alert("작품명을 입력하세요.");
    return;
  }

  // 회차 수집.
  const newEpisodes = {};
  let latestSeason = null;
  let latestEpisode = null;
  li.querySelectorAll(".ep-edit-row").forEach((row) => {
    const season = parseInt(row.querySelector(".ep-season").value, 10) || 1;
    const episode = parseInt(row.querySelector(".ep-episode").value, 10) || 1;
    const posText = row.querySelector(".ep-pos-input").value.trim();
    const posSec = parseTime(posText);
    const epKey = `${season}-${episode}`;
    // 기존 회차의 url/watchedAt 보존.
    const existing = (show.episodes || {})[epKey] || {};
    newEpisodes[epKey] = {
      season,
      episode,
      positionSec: posSec,
      positionText: posText,
      durationSec: existing.durationSec || 0,
      paused: false,
      url: existing.url || show.lastUrl || "",
      watchedAt: existing.watchedAt || Date.now(),
      updatedAt: Date.now(),
    };
    if (
      latestSeason == null ||
      season > latestSeason ||
      (season === latestSeason && episode > (latestEpisode || 0))
    ) {
      latestSeason = season;
      latestEpisode = episode;
    }
  });

  const result = await chrome.storage.local.get(STORAGE_KEY);
  const shows = result[STORAGE_KEY] || {};

  // 제목이 바뀌면 키도 변경.
  const newKey = `${show.platform}::${newTitle}`;
  delete shows[show.key];
  const updated = {
    ...show,
    title: newTitle,
    episodes: newEpisodes,
    latestSeason,
    latestEpisode,
    updatedAt: Date.now(),
  };
  delete updated.key; // 화면용 필드는 저장하지 않음.
  shows[newKey] = updated;

  await chrome.storage.local.set({ [STORAGE_KEY]: shows });

  // 수정 결과를 즉시 클라우드에 반영 (키가 바뀌었으면 옛 문서 삭제).
  try {
    const uid = await FirebaseSync.getUid();
    if (uid) {
      if (newKey !== show.key) await FirebaseSync.deleteOne(show.key);
      await FirebaseSync.uploadOne(newKey, updated);
    }
  } catch (e) {
    console.warn("[WatchDiary] 수정 내용 업로드 실패:", e.message);
  }

  loadShows();
}

// ---- 개별 삭제 ----

async function deleteSingle(key) {
  if (!confirm("이 작품을 삭제할까요?\n(로그인 상태면 폰에서도 삭제됩니다)")) return;
  const result = await chrome.storage.local.get(STORAGE_KEY);
  const shows = result[STORAGE_KEY] || {};
  delete shows[key];
  await chrome.storage.local.set({ [STORAGE_KEY]: shows });
  await deleteFromCloud([key]);
  loadShows();
}

// ---- 위치 이동 ----

function openAtPosition(url, positionSec) {
  if (!url) {
    alert("저장된 재생 URL이 없습니다.");
    return;
  }
  chrome.runtime.sendMessage({
    type: "OPEN_AT_POSITION",
    url: url,
    positionSec: positionSec,
  });
  window.close();
}

// ---- 전체 삭제 / 내보내기 ----

async function confirmClearAll() {
  const typed = prompt(
    "모든 시청 기록을 삭제하려면 아래 칸에 전체삭제를 입력하세요.\n" +
    "선택한 작품만 지우려면 상단의 ✓ 버튼을 사용하세요."
  );
  if (typed !== "전체삭제") return;

  const result = await chrome.storage.local.get(STORAGE_KEY);
  const keys = Object.keys(result[STORAGE_KEY] || {});
  const uid = await FirebaseSync.getUid().catch(() => null);

  let alsoCloud = false;
  if (uid && keys.length > 0) {
    alsoCloud = confirm(
      "클라우드(폰 앱 포함)의 전체 기록도 함께 삭제할까요?\n\n" +
      "확인: 폰에서도 모두 삭제됩니다.\n" +
      "취소: 이 PC에서만 삭제되며 다음 동기화 때 복구될 수 있습니다."
    );
  }

  await chrome.storage.local.remove(STORAGE_KEY);
  if (alsoCloud) await deleteFromCloud(keys);
  loadShows();
}

async function exportData() {
  const result = await chrome.storage.local.get(STORAGE_KEY);
  const blob = new Blob(
    [JSON.stringify(result[STORAGE_KEY] || {}, null, 2)],
    { type: "application/json" }
  );
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `watchdiary-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

/** JSON 파일에서 데이터 가져오기 (기존 데이터와 병합) */
async function importData(event) {
  const file = event.target.files[0];
  if (!file) return;
  event.target.value = ""; // 같은 파일 재선택 가능하게 초기화

  try {
    const text = await file.text();
    const imported = JSON.parse(text);

    if (!imported || typeof imported !== "object") {
      alert("올바른 WatchDiary 데이터 파일이 아닙니다.");
      return;
    }

    const result = await chrome.storage.local.get(STORAGE_KEY);
    const existing = result[STORAGE_KEY] || {};

    // 새 데이터로 기존 덮어쓰기 (같은 키면 임포트 데이터 우선, lastWatchedAt 더 최신이면 유지).
    let mergedCount = 0;
    for (const [key, show] of Object.entries(imported)) {
      if (existing[key]) {
        // 이미 있으면 더 최근 시청 기록 기준으로 병합.
        const oldTs = existing[key].lastWatchedAt || 0;
        const newTs = show.lastWatchedAt || 0;
        if (newTs >= oldTs) {
          existing[key] = show;
        } else {
          // 기존이 더 최신이면 회차만 보강.
          existing[key].episodes = { ...existing[key].episodes, ...show.episodes };
        }
      } else {
        existing[key] = show;
      }
      mergedCount++;
    }

    await chrome.storage.local.set({ [STORAGE_KEY]: existing });
    alert(`${mergedCount}개 작품을 가져왔습니다.`);
    loadShows();
  } catch (e) {
    alert("파일을 읽는 중 오류가 발생했습니다: " + e.message);
  }
}

// ---- 유틸 ----

function platformLabel(p) {
  return PLATFORM_LABELS[p] || p;
}

function escapeHtml(s) {
  const div = document.createElement("div");
  div.textContent = s;
  return div.innerHTML;
}

function escapeAttr(s) {
  return String(s).replace(/"/g, "&quot;").replace(/&/g, "&amp;");
}

/** 상단 유지관리 상태 메시지 표시. */
function setMaintenanceStatus(message, type = "") {
  const el = document.getElementById("maintenanceStatus");
  el.textContent = message;
  el.className = type || "";
  el.classList.toggle("hidden", !message);
}

/** 사용자가 직접 GitHub 최신 버전을 확인. */
async function handleManualUpdateCheck() {
  const btn = document.getElementById("checkUpdateBtn");
  btn.disabled = true;
  setMaintenanceStatus("GitHub에서 최신 버전을 확인하는 중…");

  try {
    const response = await chrome.runtime.sendMessage({
      type: "CHECK_EXTENSION_UPDATE",
    });
    if (!response?.ok) {
      throw new Error(response?.error || "업데이트 확인에 실패했습니다.");
    }

    if (response.updateAvailable) {
      await checkUpdateBanner();
      setMaintenanceStatus(
        `새 버전 ${response.latestVersion}이 있습니다. 위 다운로드를 누르세요.`,
        "success"
      );
    } else {
      setMaintenanceStatus(
        `현재 ${response.currentVersion} — 최신 버전입니다.`,
        "success"
      );
    }
  } catch (e) {
    setMaintenanceStatus(e.message, "error");
  } finally {
    btn.disabled = false;
  }
}

/** 작품이 아닌 사이트 UI 문구인지 확인. */
function isInvalidCollectedTitle(rawTitle) {
  const title = String(rawTitle || "").normalize("NFKC").trim();
  if (!title) return true;
  return /^(?:개인정보\s*(?:선호|보호)\s*센터|쿠키\s*(?:설정|선호)|privacy\s*preference\s*center|cookie\s*(?:preferences?|settings?)|manage\s*preferences?|netflix)$/i.test(title);
}

/** 재생 화면의 조작 문구인지 확인. 단독 제목으로 저장된 경우에만 정리한다. */
function isPlayerUiTitle(rawTitle) {
  const title = String(rawTitle || "").normalize("NFKC").trim();
  return /^(?:자막|자막\s*(?:및|&)\s*음성|음성|오디오|설정|재생|일시정지|다음\s*(?:화|에피소드)|건너뛰기|광고|미리보기|전체\s*화면|subtitles?|audio|settings?|play|pause|next\s*episode|skip\s*(?:intro|recap|credits)|advertisement|preview|fullscreen)$/i.test(title);
}

function hasEpisodeEvidence(show) {
  return show?.latestEpisode != null || Object.keys(show?.episodes || {}).length > 0;
}

function positivePlaybackPosition(show) {
  const positions = [show?.positionSec, show?.lastPositionSec];
  for (const episode of Object.values(show?.episodes || {})) {
    positions.push(episode?.positionSec, episode?.lastPositionSec);
  }
  return Math.max(0, ...positions.map(Number).filter(Number.isFinite));
}

/** 개인정보 UI는 항상, 플레이어 UI는 회차/재생 근거가 없을 때만 잘못된 항목이다. */
function isJunkShow(show) {
  if (isInvalidCollectedTitle(show?.title)) return true;
  return isPlayerUiTitle(show?.title) &&
    !hasEpisodeEvidence(show) &&
    positivePlaybackPosition(show) <= 0;
}

/** 회차 표기만 제거한 표시용 작품명. 접두사 유사도는 사용하지 않는다. */
function canonicalDisplayTitle(rawTitle) {
  let title = String(rawTitle || "")
    .normalize("NFKC")
    .replace(/[\u200B-\u200D\uFEFF]/g, "")
    .replace(/\s+/g, " ")
    .trim();

  const episodeSuffixes = [
    /\s*(?:[-–—|:]\s*)?S(?:EASON)?\s*\d+\s*E(?:PISODE)?\s*\d+\s*$/i,
    /\s*(?:[-–—|:]\s*)?(?:시즌\s*\d+\s*)?제?\s*\d+\s*화\s*$/i,
    /\s*(?:[-–—|:]\s*)?(?:시즌\s*\d+\s*)?EP(?:ISODE)?\.?\s*\d+\s*$/i,
  ];
  const leadingIndex = /^\s*\d{1,3}\s*[.)-]\s+(?=\S)/;
  const platformTail =
    /\s+(?:[|·]|[-–—])\s*(?:TVING|티빙|NETFLIX|넷플릭스|DISNEY\+?|디즈니\s*플러스|WAVVE|웨이브|WATCHA|왓챠)\s*$/i;

  let previous;
  do {
    previous = title;
    for (const pattern of episodeSuffixes) title = title.replace(pattern, "").trim();
    title = title.replace(leadingIndex, "").replace(platformTail, "").trim();
  } while (title && title !== previous);

  return title || String(rawTitle || "").trim();
}

/** 구조적으로 검증된 회차/플랫폼 꼬리만 제거한다. */
function canonicalTitleForShow(show, platform) {
  return canonicalDisplayTitle(show?.title);
}

/** 구두점/공백 차이만 무시한 엄격한 제목 식별자. */
function strictTitleIdentity(rawTitle) {
  return canonicalDisplayTitle(rawTitle)
    .toLocaleLowerCase("ko-KR")
    .replace(/[^\p{L}\p{N}]+/gu, "");
}

function showTimestamp(show) {
  return show.lastWatchedAt || show.updatedAt || show.createdAt || 0;
}

/** 같은 OTT + 동일한 정규화 제목인 중복 후보만 찾는다. */
function findDuplicateShowGroups(shows) {
  const grouped = new Map();
  for (const [key, show] of Object.entries(shows || {})) {
    if (isJunkShow(show)) continue;
    const platform = show.platform || key.split("::")[0] || "etc";
    const canonicalTitle = canonicalTitleForShow(show, platform);
    const identity = strictTitleIdentity(canonicalTitle);
    if (identity.length < 2) continue;
    const groupKey = `${platform}::${identity}`;
    if (!grouped.has(groupKey)) grouped.set(groupKey, []);
    grouped.get(groupKey).push({ key, show, platform, canonicalTitle });
  }
  return [...grouped.values()].filter((entries) => entries.length > 1);
}

/** 중복 작품 하나를 합치되 모든 회차를 보존한다. */
function mergeDuplicateGroup(entries) {
  const newestFirst = [...entries].sort(
    (a, b) => showTimestamp(b.show) - showTimestamp(a.show)
  );
  const newest = newestFirst[0];
  const canonicalTitle = newest.canonicalTitle ||
    canonicalTitleForShow(newest.show, newest.platform);
  let episodes = {};
  for (const entry of [...entries].sort(
    (a, b) => showTimestamp(a.show) - showTimestamp(b.show)
  )) {
    episodes = mergeEpisodes(episodes, entry.show.episodes || {});
  }

  const createdTimes = entries
    .map((entry) => entry.show.createdAt)
    .filter((value) => Number.isFinite(value) && value > 0);
  const merged = {
    ...newest.show,
    title: canonicalTitle,
    platform: newest.platform,
    createdAt: createdTimes.length ? Math.min(...createdTimes) : Date.now(),
    updatedAt: Date.now(),
    lastWatchedAt: Math.max(...entries.map((entry) => showTimestamp(entry.show))),
    episodes,
  };
  delete merged.key;

  const latest = latestOf(episodes);
  if (latest) {
    merged.latestSeason = latest.season;
    merged.latestEpisode = latest.episode;
    const latestEpisode = episodes[`${latest.season}-${latest.episode}`];
    if (latestEpisode?.url) merged.lastUrl = latestEpisode.url;
  }

  return {
    targetKey: `${newest.platform}::${canonicalTitle}`,
    merged,
    sourceKeys: entries.map((entry) => entry.key),
    title: canonicalTitle,
  };
}
/** 오프라인 정리 때 예약된 클라우드 삭제를 다음 동기화 전에 처리. */
async function flushPendingCleanupDeletes() {
  const stored = await chrome.storage.local.get("cleanup_pending_delete_keys");
  const keys = [...new Set(stored.cleanup_pending_delete_keys || [])];
  if (keys.length === 0) return;
  const uid = await FirebaseSync.getUid();
  if (!uid) return;

  const failed = [];
  for (const key of keys) {
    try {
      const ok = await FirebaseSync.deleteOne(key);
      if (!ok) failed.push(key);
    } catch {
      failed.push(key);
    }
  }
  if (failed.length > 0) {
    await chrome.storage.local.set({ cleanup_pending_delete_keys: failed });
  } else {
    await chrome.storage.local.remove("cleanup_pending_delete_keys");
  }
}

/** 병합 결과 업로드가 성공한 그룹의 원본만 클라우드에서 삭제한다. */
async function applyCloudCleanup(plans, invalidKeys) {
  let failures = 0;
  const deletableKeys = new Set(invalidKeys);

  for (const plan of plans) {
    try {
      await FirebaseSync.uploadOne(plan.targetKey, plan.merged);
      for (const key of plan.sourceKeys) {
        if (key !== plan.targetKey) deletableKeys.add(key);
      }
    } catch (e) {
      failures += 1;
      console.warn("[WatchDiary] 병합 결과 업로드 실패:", plan.title, e.message);
    }
  }

  for (const key of deletableKeys) {
    try {
      const ok = await FirebaseSync.deleteOne(key);
      if (!ok) failures += 1;
    } catch (e) {
      failures += 1;
      console.warn("[WatchDiary] 정리 대상 삭제 실패:", key, e.message);
    }
  }
  return failures;
}

/** 기존에 갈라진 동일 작품 목록을 안전하게 하나로 합친다. */
async function cleanupDuplicateShows() {
  const btn = document.getElementById("cleanupDuplicatesBtn");
  btn.disabled = true;
  setMaintenanceStatus("중복 및 잘못 수집된 항목을 분석하는 중…");

  try {
    const localResult = await chrome.storage.local.get(STORAGE_KEY);
    let shows = localResult[STORAGE_KEY] || {};
    const uid = await FirebaseSync.getUid();
    if (uid) {
      await flushPendingCleanupDeletes();
      const cloudShows = await FirebaseSync.downloadAll();
      shows = mergeShows(shows, cloudShows || {});
    }

    const invalidEntries = Object.entries(shows).filter(([, show]) =>
      isJunkShow(show)
    );
    const groups = findDuplicateShowGroups(shows);
    if (groups.length === 0 && invalidEntries.length === 0) {
      setMaintenanceStatus("정리할 중복 또는 잘못된 항목이 없습니다.", "success");
      return;
    }

    const plans = groups.map(mergeDuplicateGroup);
    const mergedCount = plans.reduce(
      (sum, plan) => sum + plan.sourceKeys.length - 1,
      0
    );
    const previewLines = [
      ...plans.slice(0, 4).map(
        (plan) => `• 병합: ${plan.title} (${plan.sourceKeys.length}개 → 1개)`
      ),
      ...invalidEntries.slice(0, 3).map(
        ([, show]) => `• 잘못 수집된 UI 삭제: ${show.title}`
      ),
    ];
    const totalActions = plans.length + invalidEntries.length;
    const shownActions = Math.min(plans.length, 4) + Math.min(invalidEntries.length, 3);
    const more = totalActions > shownActions
      ? `\n외 ${totalActions - shownActions}개 항목`
      : "";
    const approved = confirm(
      `중복 ${mergedCount}개를 합치고 잘못 수집된 UI ${invalidEntries.length}개를 삭제합니다.\n` +
      `정상 회차 기록은 모두 보존합니다.\n\n${previewLines.join("\n")}${more}`
    );
    if (!approved) {
      setMaintenanceStatus("목록 정리를 취소했습니다.");
      return;
    }

    const cleaned = { ...shows };
    const obsoleteKeys = [];
    for (const [key] of invalidEntries) {
      delete cleaned[key];
      obsoleteKeys.push(key);
    }
    for (const plan of plans) {
      for (const key of plan.sourceKeys) delete cleaned[key];
      cleaned[plan.targetKey] = plan.merged;
      obsoleteKeys.push(
        ...plan.sourceKeys.filter((key) => key !== plan.targetKey)
      );
    }
    const uniqueObsoleteKeys = [...new Set(obsoleteKeys)];
    await chrome.storage.local.set({ [STORAGE_KEY]: cleaned });

    let cloudFailures = 0;
    if (uid) {
      cloudFailures = await applyCloudCleanup(
        plans,
        invalidEntries.map(([key]) => key)
      );
    } else if (uniqueObsoleteKeys.length > 0) {
      const stored = await chrome.storage.local.get("cleanup_pending_delete_keys");
      const pending = new Set(stored.cleanup_pending_delete_keys || []);
      uniqueObsoleteKeys.forEach((key) => pending.add(key));
      await chrome.storage.local.set({
        cleanup_pending_delete_keys: [...pending],
      });
    }

    loadShows();
    const summary = `중복 ${mergedCount}개 병합 · 잘못된 UI ${invalidEntries.length}개 삭제`;
    if (cloudFailures > 0) {
      setMaintenanceStatus(
        `${summary}. 클라우드 ${cloudFailures}건은 다시 동기화가 필요합니다.`,
        "error"
      );
    } else {
      setMaintenanceStatus(`${summary} 완료`, "success");
    }
  } catch (e) {
    setMaintenanceStatus(`목록 정리 실패: ${e.message}`, "error");
  } finally {
    btn.disabled = false;
  }
}
function relativeTime(ts) {
  if (!ts) return "";
  const diff = Date.now() - ts;
  const min = Math.floor(diff / 60000);
  const hour = Math.floor(min / 60);
  const day = Math.floor(hour / 24);
  if (min < 1) return "방금";
  if (min < 60) return `${min}분 전`;
  if (hour < 24) return `${hour}시간 전`;
  if (day < 30) return `${day}일 전`;
  const d = new Date(ts);
  return `${d.getMonth() + 1}.${d.getDate()}`;
}

/** "mm:ss" 또는 "h:mm:ss" → 초 */
function parseTime(text) {
  if (!text) return 0;
  const parts = text.split(":").map((p) => parseInt(p.trim(), 10));
  if (parts.some(isNaN)) return 0;
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  return 0;
}

/** 업데이트 배너 표시. */
async function checkUpdateBanner() {
  const { update_available, update_version, update_url, update_html } =
    await chrome.storage.local.get([
      "update_available", "update_version", "update_url", "update_html",
    ]);
  if (update_available && update_version) {
    const banner = document.getElementById("updateBanner");
    document.getElementById("updateVersion").textContent = update_version;
    const link = document.getElementById("updateLink");
    link.onclick = (e) => {
      e.preventDefault();
      window.open(
        update_url || update_html || "https://github.com/msk92221-creator/watchdiary-downloads/releases",
        "_blank"
      );
    };
    banner.classList.remove("hidden");
  }
}
